package com.example.districtapp;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;
import java.util.Date;

public class VisitorMain extends AppCompatActivity {
    private int i = 0;
    Button button7,button25;
    ListView lv2;
    TextView txtView;
    ArrayList<itemMail> ar = new ArrayList<>();
    String userID,key,xx,xxx;
    FirebaseAuth firebaseAuth;
    FirebaseFirestore firebaseFirestore;
    ImageView imageView,imageView2;
    private ProgressBar pgsBar;
    private Handler hdlr = new Handler();


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.visitor_listview);
        button7 = findViewById(R.id.button7);
        button25 = findViewById(R.id.button25);
        lv2 = findViewById(R.id.lv2);
        pgsBar = (ProgressBar) findViewById(R.id.pBar);
        imageView= findViewById(R.id.imageView27);
        imageView2=findViewById(R.id.imageView28);
        txtView = (TextView) findViewById(R.id.tView);
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();
        userID = firebaseAuth.getCurrentUser().getUid();
        txtView.setVisibility(View.INVISIBLE);
        pgsBar.setVisibility(View.INVISIBLE);
        imageView2.setVisibility(View.INVISIBLE);
        DocumentReference documentReference = firebaseFirestore.collection("users").document(userID);
        documentReference.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document != null) {
                        Log.d("TAG", "DocumentSnapshot data: " + document.getData());

                        key = document.getString("recID");
                        firebaseFirestore.collection("Visitor").whereEqualTo("recID", key.toString()).orderBy("createdAt",Query.Direction.DESCENDING).addSnapshotListener((documentSnapshots, error) -> {
                            ar.clear();
                            for (DocumentSnapshot snapshot : documentSnapshots) {
                                Timestamp timestamp = (Timestamp) snapshot.getData().get("actual_arrival_time");
                                Date date = timestamp.toDate();
                                String date2 = date.toString();
                                Timestamp timestamp2 = (Timestamp) snapshot.getData().get("actual_leave_time");
                                Date date3 = timestamp2.toDate();
                                String date4 = date3.toString();
                                String status = snapshot.getString("visitor_status");
                                ar.add(new itemMail(R.drawable.profile55, "訪客姓名:"+snapshot.getString("visitor_name"), "手機電話: " + snapshot.getString("phone"), "到達時間"+date2,"離開時間"+date4,status));
                            }
                            adapterMail adapterMail = new adapterMail(getApplicationContext(), R.layout.list_row_mail, ar);
                            adapterMail.notifyDataSetChanged();
                            lv2.setAdapter(adapterMail);
                        });
                        lv2 = findViewById(R.id.lv2);
                    }
                }
            }
        });
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i = pgsBar.getProgress();
                new Thread(new Runnable() {
                    public void run() {
                        //txtView.setVisibility(View.VISIBLE);

                        while (i < 100) {
                            i += 10;
                            // Update the progress bar and display the current value in text view
                            hdlr.post(new Runnable() {
                                public void run() {
                                    pgsBar.setVisibility(View.VISIBLE);
                                    txtView.setVisibility(View.VISIBLE);
                                    imageView2.setVisibility(View.VISIBLE);
                                    pgsBar.setProgress(i);
                                    txtView.setText("自動生成表單連結中...");
                                }
                            });
                            try {
                                // Sleep for 100 milliseconds to show the progress slowly.
                                Thread.sleep(100);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            if(i == 90){
                                pgsBar.setVisibility(View.INVISIBLE);
                                txtView.setVisibility(View.INVISIBLE);
                                startActivity(new Intent(VisitorMain.this, VisitorPage.class));
                            }
                        }
                    }
                }).start();

            }
        });
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(VisitorMain.this, CommunityDaily.class));
            }
        });

    }
}

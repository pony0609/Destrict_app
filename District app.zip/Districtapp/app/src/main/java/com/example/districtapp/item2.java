package com.example.districtapp;

import com.google.firebase.firestore.Exclude;

import java.io.Serializable;

public class item2 implements Serializable {
    @Exclude
    private String id;
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDes() {
        return Des;
    }

    public void setDes(String des) {
        Des = des;
    }


    String name;
    String Des;
    public item2( String name, String des) {

        this.name = name;
        Des = des;
    }
}

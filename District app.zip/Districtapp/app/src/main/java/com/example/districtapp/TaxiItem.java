package com.example.districtapp;

public class TaxiItem {
    private String mTaxiName;
    private int mTaxiImage;

    public TaxiItem(String taxiName,int taxiImage){
        mTaxiName=taxiName;
        mTaxiImage=taxiImage;
    }

    public String getmTaxiName(){
        return mTaxiName;
    }
    
    public int getmTaxiImage(){
        return mTaxiImage;
    }
}

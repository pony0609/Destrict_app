package com.example.districtapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivityGas extends AppCompatActivity {
    private RecyclerView recyclerView;
    private MyAdapter myAdapter;
    private RecyclerView.LayoutManager layoutManager;
    LinearLayout linearLayout;
    ArrayList gas = new ArrayList();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_gas);
        linearLayout = findViewById(R.id.LinearLayout);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        myAdapter = new MyAdapter();
        recyclerView.setAdapter(myAdapter);


    }

    private class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder>{
        Resources res =getResources();
        String[] months=res.getStringArray(R.array.months);
        class MyViewHolder extends RecyclerView.ViewHolder {
            public View itemView;
            public TextView gases,month;
            
            public MyViewHolder(View v) {
                super(v);
                itemView = v;

                gases = v.findViewById(R.id.gas);
                month = v.findViewById(R.id.month);
            }
        }

        @NonNull
        @Override
        public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            TextView itemView = (TextView)LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item3, parent, false);

            MyViewHolder vh = new MyViewHolder(itemView);
            return vh;
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
            holder.month.setText(months[position]);
            holder.gases.setText(read());
        }

        @Override
        public int getItemCount() {
            return read().length();
        }
    }
    private String read(){
        /**創建SharedPreferences，索引為"Data"*/
        SharedPreferences sharedPreferences = getSharedPreferences("Data", Context.MODE_PRIVATE);
        gas.add(sharedPreferences);
        /**回傳在"Saved"索引之下的資料；若無儲存則回傳"未存任何資料"*/
        return sharedPreferences.getString("Saved","未存任何資料");
    }
    private void clear(){
        /**創建SharedPreferences*/
        SharedPreferences sharedPreferences = getSharedPreferences("Data",Context.MODE_PRIVATE);
        /**取得SharedPreferences.Editor*/
        SharedPreferences.Editor editor = sharedPreferences.edit();
        /**利用clear清除掉所有資料*/
        editor.clear();
        /**不返回結果的提交*/
        /**若需要提交結果，則可使用.commit()*/
        editor.apply();

    }

    public void btGoSave(View v){
        Intent intent = new Intent(this,SavedDataMainActivity.class);
        startActivity(intent);
    }
    public void btClear(View v){
        clear();
    }
}
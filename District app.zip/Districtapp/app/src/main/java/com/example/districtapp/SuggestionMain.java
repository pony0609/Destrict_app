package com.example.districtapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;
import java.util.Date;

public class SuggestionMain extends AppCompatActivity {
    Button button7;
    ListView lv1;
    ArrayList<itemAnnounce> ar = new ArrayList<>();
    String userID,idlv,url,recID,date2;
    FirebaseAuth firebaseAuth;
    FirebaseFirestore firebaseFirestore;
    ImageView imageView;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.suggestion_main);
        button7 = findViewById(R.id.button7);
        imageView = findViewById(R.id.imageView30);
        lv1 = findViewById(R.id.lv2);


        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();
        userID = firebaseAuth.getCurrentUser().getUid();

        DocumentReference docRef = firebaseFirestore.collection("users").document(userID);
        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Log.d("TAG", "DocumentSnapshot data: " + document.getData());
                        recID = document.getString("recID");
                        firebaseFirestore.collection("Suggestion").whereEqualTo("recID",recID).orderBy("createdAt", Query.Direction.DESCENDING).addSnapshotListener((documentSnapshots, error) -> {
                            ar.clear();

                            for (DocumentSnapshot snapshot : documentSnapshots){
                                idlv = snapshot.getId();

                                if (snapshot.getDate("createdAt") != null) {
                                   //  Date timestamp = snapshot.getDate("createdAt");
                                    //Do what you need to do with this timestamp
                                     Timestamp timestamp = (Timestamp) snapshot.getData().get("createdAt");
                                    Date date = timestamp.toDate();
                                     date2 = date.toString();
                                }


                                ar.add(new itemAnnounce(R.drawable.notes, snapshot.getString("title"),"回饋於 "+date2,"回覆管理者:"+snapshot.getString("admin_name"),"回覆狀態:"+snapshot.getString("response_status"),idlv,url));


                            }
                            adapterAnnounce adapterAnnounce = new adapterAnnounce(getApplicationContext(), R.layout.list_row_announce, ar);
                            adapterAnnounce.notifyDataSetChanged();
                            lv1.setAdapter(adapterAnnounce);

                            lv1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                @Override
                                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                    Object selectedObj =adapterAnnounce.getItem(position).getId();// this will get you selected obj of itemAnnounce
                                    String obj = (String)selectedObj.toString();

                                    Intent i = new Intent(SuggestionMain.this,SugesstionPage.class);
                                    i.putExtra("annId",obj);
                                    startActivity(i);
                                }
                            });
                        });
                    } else {
                        Log.d("TAG", "No such document");
                    }
                } else {
                    Log.d("TAG", "get failed with ", task.getException());
                }
            }
        });



        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SuggestionMain.this, CommunityDaily.class));
            }
        });
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SuggestionMain.this, create_announce_main.class));
                SuggestionMain.this.finish();
            }
        });
    }
}

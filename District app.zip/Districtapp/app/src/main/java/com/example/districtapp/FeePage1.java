package com.example.districtapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.util.Date;

public class FeePage1 extends AppCompatActivity {
    ImageView on;
    Button button7,button2,button14;
    String userID,docID;
    TextView mTitle,dTitle,deaddate,pStatus,content,status;

    FirebaseAuth firebaseAuth;
    FirebaseFirestore firebaseFirestore;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.feepage1);
        mTitle = findViewById(R.id.textView37);
        dTitle = findViewById(R.id.textView38);
        deaddate = findViewById(R.id.textView40);
        pStatus = findViewById(R.id.textView41);
        content = findViewById(R.id.textView43);
        button7 = findViewById(R.id.button7);
        button2 = findViewById(R.id.button2);
        button14 = findViewById(R.id.button14);
        on = findViewById(R.id.imageView36);
        status = findViewById(R.id.textView41);
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();
        userID = firebaseAuth.getCurrentUser().getUid();
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FeePage1.this, CommunityDaily.class));
            }
        });


        firebaseFirestore.collection("feeManage").whereEqualTo("狀態", "已啟用").addSnapshotListener((documentSnapshots, error) -> {

            for (DocumentSnapshot snapshot : documentSnapshots) {
                docID = snapshot.getId();
                DocumentReference docRef = firebaseFirestore.collection("users").document(userID).collection("feeManage").document(docID);
                docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                            if (document.exists()) {
                            status.setText(document.getString("繳費狀態"));
                                AlertDialog.Builder builder1 = new AlertDialog.Builder(FeePage1.this);
                                builder1.setMessage("您已繳納當期管理費");
                                builder1.setCancelable(true);

                                builder1.setPositiveButton(
                                        "返回社區生活",
                                        new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                dialog.cancel();
                                                startActivity(new Intent(FeePage1.this, CommunityDaily.class));

                                            }
                                        });


                                AlertDialog alert11 = builder1.create();
                                alert11.show();
                                on.setOnClickListener(new View.OnClickListener() {

                                    @Override
                                    public void onClick(View v) {

                                        AlertDialog.Builder builder1 = new AlertDialog.Builder(FeePage1.this);
                                        builder1.setMessage("您已繳納當期管理費");
                                        builder1.setCancelable(true);

                                        builder1.setPositiveButton(
                                                "返回社區生活",
                                                new DialogInterface.OnClickListener() {
                                                    public void onClick(DialogInterface dialog, int id) {
                                                        dialog.cancel();
                                                        startActivity(new Intent(FeePage1.this, CommunityDaily.class));

                                                    }
                                                });


                                        AlertDialog alert11 = builder1.create();
                                        alert11.show();

                                    }
                                });
                            }else{
                                on.setOnClickListener(new View.OnClickListener() {

                                    @Override
                                    public void onClick(View v) {

                                        startActivity(new Intent(FeePage1.this, FeePage2.class));

                                    }
                                });
                            }
                        } else {

                            Log.d("TAG", "No such document");
                        }
                    }

                });
                Timestamp timestamp = (Timestamp) snapshot.getData().get("繳費期限");
                Date date = timestamp.toDate();
                String date2 = date.toString();

                mTitle.setText(snapshot.getString("期別名稱"));
                dTitle.setText(snapshot.getString("社區名稱"));
                deaddate.setText(date2);
                content.setText(snapshot.getString("期別備註"));


            }

        });
        button14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FeePage1.this, FeeRDPage.class));
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FeePage1.this, FeePage1.class));
            }
        });


    }
}

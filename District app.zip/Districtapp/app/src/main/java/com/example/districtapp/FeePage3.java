package com.example.districtapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class FeePage3 extends AppCompatActivity {
    ImageView go;
    Button back;
    EditText cardN,cardD,card3;
    TextView mTitle,dTitle,deaddate,full;
    String userID,docID,recID;
    private ProgressDialog progressDialog;
    FirebaseAuth firebaseAuth;
    FirebaseFirestore firebaseFirestore;
    int squareF,SpotF,squareA,SpotA,squareAll,SpotAll,AllFee;
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.feepage3);

        mTitle = findViewById(R.id.textView46);
        dTitle = findViewById(R.id.textView47);
        deaddate = findViewById(R.id.textView49);
        full = findViewById(R.id.textView51);
        cardN = findViewById(R.id.editTextTextPersonName);
        cardD = findViewById(R.id.editTextTextPersonName2);
        card3 = findViewById(R.id.editTextTextPersonName3);
        go = findViewById(R.id.imageView38);
        back = findViewById(R.id.button7);
        progressDialog = new ProgressDialog(FeePage3.this);
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();
        userID = firebaseAuth.getCurrentUser().getUid();


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FeePage3.this, FeePage2.class));
            }
        });
        DocumentReference docRef = firebaseFirestore.collection("users").document(userID);


        firebaseFirestore.collection("feeManage").whereEqualTo("狀態", "已啟用").addSnapshotListener((documentSnapshots, error) -> {

            for (DocumentSnapshot snapshot : documentSnapshots) {
                Timestamp timestamp = (Timestamp) snapshot.getData().get("繳費期限");
                Date date = timestamp.toDate();
                String date2 = date.toString();
                docID = snapshot.getId();
                mTitle.setText(snapshot.getString("期別名稱"));
                dTitle.setText(snapshot.getString("社區名稱"));
                deaddate.setText(date2);

                squareF = snapshot.getLong("每坪台幣").intValue();
                SpotF = snapshot.getLong("每車位台幣").intValue();

                docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                            if (document.exists()) {
                                recID = document.getString("recID");
                                squareA = document.getLong("square").intValue();
                                SpotA = document.getLong("parkingspotNum").intValue();
                                squareAll = squareA * squareF;
                                SpotAll = SpotA * SpotF;
                                AllFee = squareAll + SpotAll +10;
                                full.setText("$"+AllFee);
                                go.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        progressDialog.setMessage("繳款訊息處理中");
                                        progressDialog.show();
                                        String CardN = cardN.getText().toString();
                                        String CardD = cardD.getText().toString();
                                        String Card3 = card3.getText().toString();

                                        if(CardN == null | CardD == null | Card3 == null){
                                            Toast.makeText(FeePage3.this, "請輸入信用卡資料", Toast.LENGTH_LONG).show();
                                        }else{
                                            Map<String, Object> FeeUsers = new HashMap<>();
                                            FeeUsers.put("recID", recID);
                                            FeeUsers.put("付款方式", "信用卡");
                                            FeeUsers.put("信用卡卡號", CardN);
                                            FeeUsers.put("信用卡到期日", CardD);
                                            FeeUsers.put("信用卡後3碼", Card3);
                                            FeeUsers.put("繳費期別", snapshot.getString("期別名稱"));
                                            FeeUsers.put("付款日期", FieldValue.serverTimestamp());
                                            FeeUsers.put("應付帳款", AllFee);
                                            FeeUsers.put("實付帳款", AllFee);
                                            FeeUsers.put("收據編號", "STANDBY");
                                            FeeUsers.put("繳費狀態", "已繳費");
                                            firebaseFirestore.collection("feeManage").document(docID).collection("users").document(userID).set(FeeUsers).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task) {
                                                    if (task.isSuccessful()) {
                                                       // Toast.makeText(FeePage3.this, "資訊上傳中", Toast.LENGTH_LONG).show();


                                                    }
                                                }
                                            });
                                            firebaseFirestore.collection("users").document(userID).collection("feeManage").document(docID).set(FeeUsers).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task) {
                                                    if (task.isSuccessful()) {
                                                       // Toast.makeText(FeePage3.this, "資訊上傳中2", Toast.LENGTH_LONG).show();


                                                    }
                                                }
                                            });
                                            startActivity(new Intent(FeePage3.this, FeePageSuc.class));
                                        }

                                    }
                                });

                            }
                        } else {
                            Log.d("TAG", "No such document");
                        }
                    }

                });
            }

        });

    }
}

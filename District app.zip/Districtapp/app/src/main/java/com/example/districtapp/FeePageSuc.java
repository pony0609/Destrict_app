package com.example.districtapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Date;

public class FeePageSuc extends AppCompatActivity {
    TextView full;
    ImageView back;
    String userID;
    FirebaseAuth firebaseAuth;
    FirebaseFirestore firebaseFirestore;
    int squareF,SpotF,squareA,SpotA,squareAll,SpotAll,AllFee;
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.feepagesuc);
        full = findViewById(R.id.textView67);
        back = findViewById(R.id.imageView38);
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();
        userID = firebaseAuth.getCurrentUser().getUid();

        DocumentReference docRef = firebaseFirestore.collection("users").document(userID);
        firebaseFirestore.collection("feeManage").whereEqualTo("狀態", "已啟用").addSnapshotListener((documentSnapshots, error) -> {

            for (DocumentSnapshot snapshot : documentSnapshots) {

                squareF = snapshot.getLong("每坪台幣").intValue();
                SpotF = snapshot.getLong("每車位台幣").intValue();

                docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                            if (document.exists()) {
                                squareA = document.getLong("square").intValue();
                                SpotA = document.getLong("parkingspotNum").intValue();
                                squareAll = squareA * squareF;
                                SpotAll = SpotA * SpotF;
                                AllFee = squareAll + SpotAll;
                                full.setText("$"+AllFee);

                            }
                        } else {
                            Log.d("TAG", "No such document");
                        }
                    }

                });
            }

        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FeePageSuc.this, FeePage1.class));
            }
        });
    }
}

package com.example.districtapp;

import com.google.firebase.firestore.Exclude;

import java.io.Serializable;

public class itemMail implements Serializable {
    @Exclude

    public int getImage() {
        return image;
    }
    public void setImage(int image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getAdmin() {
        return admin;
    }
    public void setAdmin(String admin) {
        this.admin = admin;
    }

    public String getTime() {
        return time;
    }
    public void setTime(String time) {
        this.time = time;
    }

    public String getEnd() {
        return end;
    }
    public void setEnd(String end) {
        this.end = end;
    }

    public String getAccept() {
        return accept;
    }
    public void setAccept(String accept) {
        this.accept = accept;
    }



    int image;
    String name;
    String admin;
    String time;
    String end;
    String accept;
    public itemMail(int image, String name, String admin, String time, String end,String accept) {
        this.image = image;
        this.name = name;
        this.admin = admin;
        this.time = time;
        this.end = end;
        this.accept =accept;
    }


}
package com.example.districtapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Date;

public class FeePage2 extends AppCompatActivity {
    ImageView go;
    Button back;
    TextView mTitle,dTitle,deaddate,full,halfa,halfb,fullab,content;
    String userID,docID;
    int squareF,SpotF,squareA,SpotA,squareAll,SpotAll,AllFee;
    FirebaseAuth firebaseAuth;
    FirebaseFirestore firebaseFirestore;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.feepage2);
        mTitle = findViewById(R.id.textView46);
        dTitle = findViewById(R.id.textView47);
        deaddate = findViewById(R.id.textView49);
        full = findViewById(R.id.textView51);
        halfa = findViewById(R.id.textView57);
        halfb = findViewById(R.id.textView58);
        fullab = findViewById(R.id.textView59);
        content = findViewById(R.id.textView61);
        go = findViewById(R.id.imageView38);
        back  = findViewById(R.id.button7);
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();
        userID = firebaseAuth.getCurrentUser().getUid();

        go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FeePage2.this, FeePage3.class));
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FeePage2.this, FeePage1.class));
            }
        });
        DocumentReference docRef = firebaseFirestore.collection("users").document(userID);
        firebaseFirestore.collection("feeManage").whereEqualTo("狀態", "已啟用").addSnapshotListener((documentSnapshots, error) -> {

            for (DocumentSnapshot snapshot : documentSnapshots) {
                Timestamp timestamp = (Timestamp) snapshot.getData().get("繳費期限");
                Date date = timestamp.toDate();
                String date2 = date.toString();
                docID = snapshot.getId();
                mTitle.setText(snapshot.getString("期別名稱"));
                dTitle.setText(snapshot.getString("社區名稱"));
                deaddate.setText(date2);
                content.setText(snapshot.getString("期別備註"));
                squareF = snapshot.getLong("每坪台幣").intValue();
                SpotF = snapshot.getLong("每車位台幣").intValue();

                docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                            if (document.exists()) {
                                squareA = document.getLong("square").intValue();
                                SpotA = document.getLong("parkingspotNum").intValue();
                                squareAll = squareA * squareF;
                                SpotAll = SpotA * SpotF;
                                AllFee = squareAll + SpotAll;
                                full.setText("$"+AllFee);
                                halfa.setText("$"+squareAll);
                                halfb.setText("$"+SpotAll);
                                fullab.setText("$"+AllFee);
                            }
                        } else {
                            Log.d("TAG", "No such document");
                        }
                    }

                });
            }

        });




    }
}

package com.example.districtapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

public class ConventMain extends AppCompatActivity {
    ArrayList<item2> ar = new ArrayList<>();
    ListView lv3;
    Button update;
    String userID;
    FirebaseAuth firebaseAuth;
    FirebaseFirestore firebaseFirestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.convent_main);
        lv3 = findViewById(R.id.lv3);
        update = findViewById(R.id.update);

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();
        userID = firebaseAuth.getCurrentUser().getUid();
        firebaseFirestore.collection("convent").addSnapshotListener(new EventListener<QuerySnapshot>() {

            @Override
            public void onEvent(@Nullable QuerySnapshot documentSnapshots, @Nullable FirebaseFirestoreException error) {

                ar.clear();
                for (DocumentSnapshot snapshot : documentSnapshots) {
                    ar.add(new item2(snapshot.getString("title"), snapshot.getString("content")));


                }
                adapter3 adapter3 = new adapter3(getApplicationContext(), R.layout.list_row_convent, ar);
                adapter3.notifyDataSetChanged();
                lv3.setAdapter(adapter3);
            }
        });
        // final adapter3 adapter3 = new adapter3(ConventMain.this, R.layout.list_row_convent, ar);
        // lv3.setAdapter(adapter3);
       update.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent intent = new Intent(ConventMain.this, UpdateConvent.class);
               startActivity(intent);
           }
       });


    }



}

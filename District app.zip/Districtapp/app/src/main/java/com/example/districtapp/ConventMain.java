package com.example.districtapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Date;

public class ConventMain extends AppCompatActivity {
    Button button7;
    TextView createBy,update;
    ArrayList<item2> ar = new ArrayList<>();
    ListView lv3;
    String userID;
    FirebaseAuth firebaseAuth;
    FirebaseFirestore firebaseFirestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.convent_main);
        lv3 = findViewById(R.id.lv3);
        button7 = findViewById(R.id.button7);
        update = findViewById(R.id.textView15);
        createBy = findViewById(R.id.textView16);


        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();
        userID = firebaseAuth.getCurrentUser().getUid();
        firebaseFirestore.collection("convent").addSnapshotListener(new EventListener<QuerySnapshot>() {

            @Override
            public void onEvent(@Nullable QuerySnapshot documentSnapshots, @Nullable FirebaseFirestoreException error) {

                ar.clear();
                for (DocumentSnapshot snapshot : documentSnapshots) {
                    ar.add(new item2(snapshot.getString("title"), snapshot.getString("content")));


                }
                adapter3 adapter3 = new adapter3(getApplicationContext(), R.layout.list_row_convent, ar);
                adapter3.notifyDataSetChanged();
                lv3.setAdapter(adapter3);
            }
        });

        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ConventMain.this, CommunityDaily.class));
            }
        });
        DocumentReference docRef = firebaseFirestore.collection("convent").document("lVIUrPt4MTpub2HHINGa");
        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Timestamp timestamp = (Timestamp) document.getData().get("createdAt");
                        Date date = timestamp.toDate();
                        String date2 = date.toString();
                        Log.d("TAG", "DocumentSnapshot data: " + document.getData());
                        update.setText(date2);
                        createBy.setText(document.getString("createdBy"));

                    } else {
                        Log.d("TAG", "No such document");
                    }
                } else {
                    Log.d("TAG", "get failed with ", task.getException());
                }

            }
        });




    }



}

package com.example.districtapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.bumptech.glide.Glide;
import com.denzcoskun.imageslider.ImageSlider;
import com.denzcoskun.imageslider.models.SlideModel;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class HomePageActivity extends AppCompatActivity {
    Button icon_daily,icon_inter,icon_announce;
    ImageView icon_main,icon_contact,icon_b,icon_idv;
    ImageSlider imageSlider;
    TextView title;
    FirebaseAuth firebaseAuth;
    FirebaseFirestore firebaseFirestore;
    String userID;
    DrawerLayout drawerLayout;
    Button button3;
    ArrayList<String> ar = new ArrayList<>();


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_BACK)) {
            if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                drawerLayout.closeDrawers();
            }else finish();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.homepage);
       button3 =  findViewById(R.id.button3);
       drawerLayout = findViewById(R.id.myDrawerLayout);



        button3.setOnClickListener((v -> {
            Toast.makeText(this,"點擊了第一個Button",Toast.LENGTH_SHORT).show();
        }));


        icon_announce = findViewById(R.id.icon_announce);
        imageSlider = findViewById(R.id.imageSlider);
        icon_inter = findViewById(R.id.icon_inter);
        icon_daily = findViewById(R.id.icon_daily);
        title = findViewById(R.id.title);
        icon_main = findViewById(R.id.icon_main);
        icon_b = findViewById(R.id.icon_b);
        icon_contact = findViewById(R.id.icon_contact);
        icon_idv = findViewById(R.id.icon_idv);
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();
        userID = firebaseAuth.getCurrentUser().getUid();

       // DocumentReference documentReference = firebaseFirestore.collection("announcement").document(userID);
      //  documentReference.addSnapshotListener(this, (documentSnapshot, error) -> title.setText(documentSnapshot.getString("user_name")));
        firebaseFirestore.collection("announcement").orderBy("createdAt", Query.Direction.DESCENDING).limit(1).addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot documentSnapshots, @Nullable FirebaseFirestoreException error) {
                ar.clear();
                for (DocumentSnapshot snapshot : documentSnapshots) {
                    //item item = snapshot.toObject(item.class);
                    // item.setId(snapshot.getId());
                    ar.add(snapshot.getString("title"));
                    title.setText(snapshot.getString("title"));
                }
            }
            });

        List<SlideModel> slideModels = new ArrayList<>();
        slideModels.add(new SlideModel("https://wallpaperaccess.com/full/869.jpg"));
        slideModels.add(new SlideModel("https://wallpaperaccess.com/full/4107751.jpg"));
        slideModels.add(new SlideModel("https://i.pinimg.com/736x/77/90/cc/7790ccc06dc3a75bd99dba04bd96d49c.jpg"));
        slideModels.add(new SlideModel("https://wallpaperaccess.com/full/2704587.jpg"));
        imageSlider.setImageList(slideModels,true);
        icon_idv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomePageActivity.this, profile.class);
                startActivity(intent);
            }
        });

        icon_contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomePageActivity.this, ChatMain.class);
                startActivity(intent);
            }
        });
        icon_daily.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomePageActivity.this, CommunityDaily.class);
                startActivity(intent);
            }
        });
        icon_inter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomePageActivity.this, CommunitySocial.class);
                startActivity(intent);
            }
        });
        icon_announce.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomePageActivity.this, announce_main.class);
                startActivity(intent);
            }
        });




    }

}

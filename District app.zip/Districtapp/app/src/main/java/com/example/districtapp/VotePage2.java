package com.example.districtapp;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class VotePage2 extends AppCompatActivity implements Serializable {
    Button button_A,button_B,button7,button_C,button_D;
    TextView vote_title,vote_create,vote_start,vote_end,vote_content;
    FirebaseAuth firebaseAuth;
    FirebaseFirestore firebaseFirestore;
    String voteId,userID,av,bv,cv,dv,result;
    ListView lv2;
    int a,b,c,d;


    ArrayList<item2> ar = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.vote_page2);
        button7 = findViewById(R.id.button7);
        button_A = findViewById(R.id.button);
        button_B = findViewById(R.id.button24);
        button_C = findViewById(R.id.button22);
        button_D = findViewById(R.id.button23);
        vote_title = findViewById(R.id.textView7);
        vote_create = findViewById(R.id.textView8);
        vote_start = findViewById(R.id.textView9);
        vote_end = findViewById(R.id.textView10);
        vote_content = findViewById(R.id.textView11);
        lv2 = findViewById(R.id.lv2);
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();
        userID = firebaseAuth.getCurrentUser().getUid();

        if (savedInstanceState == null) {
            Bundle extras = getIntent().getExtras();
            if (extras == null) {
                voteId = null;
            } else {
                voteId = extras.getString("voteId");
            }
        } else {
            voteId = (String) savedInstanceState.getSerializable("voteId");
        }
        DocumentReference docRef2 = firebaseFirestore.collection("users").document(userID).collection("vote").document(voteId);

        docRef2.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Log.d("TAG", "DocumentSnapshot data: " + document.getData());
                        AlertDialog.Builder builder1 = new AlertDialog.Builder(VotePage2.this);
                        builder1.setMessage("您已投過該投票");
                        builder1.setCancelable(true);

                        builder1.setPositiveButton(
                                "確定返回",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        dialog.cancel();
                                        startActivity(new Intent(VotePage2.this, VoteMain.class));

                                    }
                                });


                        AlertDialog alert11 = builder1.create();
                        alert11.show();

                    }
                } else {
                    Log.d("TAG", "No such document");
                }
            }

        });


        DocumentReference docRef = firebaseFirestore.collection("vote").document(voteId);
        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Log.d("TAG", "DocumentSnapshot data: " + document.getData());
                        vote_title.setText(document.getString("vote_title"));
                        vote_create.setText(document.getString("createdBy"));
                        vote_start.setText(document.getString("start_time"));
                        vote_end.setText(document.getString("end_time"));
                        vote_content.setText(document.getString("vote_content"));
                        av = document.getString("A");
                        bv = document.getString("B");
                        cv = document.getString("C");
                        dv = document.getString("D");
                        result = document.getString("result");
                        if (cv.equals("")) {


                            button_C.setVisibility(View.INVISIBLE);
                            button_D.setVisibility(View.INVISIBLE);

                        }else if(!cv.equals("") && dv.equals("")){
                            button_D.setVisibility(View.INVISIBLE);
                        }else{

                        }

                        button_A.setText(document.getString("A"));
                        button_B.setText(document.getString("B"));
                        button_C.setText(document.getString("C"));
                        button_D.setText(document.getString("D"));
                        ar.add(new item2(document.getString("vote_title"), document.getString("vote_description")));
                        a = document.getLong("選項1").intValue();
                        b = document.getLong("選項2").intValue();
                        c = document.getLong("選項3").intValue();
                        d = document.getLong("選項4").intValue();

                    } else {
                        Log.d("TAG", "No such document");
                    }
                } else {
                    Log.d("TAG", "get failed with ", task.getException());
                }
                adapter3 adapter3 = new adapter3(getApplicationContext(), R.layout.list_row_convent, ar);
                adapter3.notifyDataSetChanged();
                lv2.setAdapter(adapter3);
            }
        });


        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(VotePage2.this, VoteMain.class));
            }
        });
        button_A.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                docRef2.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                            if (document.exists()) {
                                Log.d("TAG", "DocumentSnapshot data: " + document.getData());
                                AlertDialog.Builder builder1 = new AlertDialog.Builder(VotePage2.this);
                                builder1.setMessage("您已投過該投票");
                                builder1.setCancelable(true);

                                builder1.setPositiveButton(
                                        "確定返回",
                                        new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                dialog.cancel();
                                                startActivity(new Intent(VotePage2.this, VoteMain.class));

                                            }
                                        });


                                AlertDialog alert11 = builder1.create();
                                alert11.show();

                            }
                        } else {
                            Log.d("TAG", "No such document");
                        }
                    }

                });

                AlertDialog.Builder builder1 = new AlertDialog.Builder(VotePage2.this);
                builder1.setMessage("確定投下"+av+"嗎?"+" 一經投票不可更改.");
                builder1.setCancelable(true);

                builder1.setPositiveButton(
                        "Yes",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();

                                Map<String, Object> vote = new HashMap<>();
                                a++;
                                vote.put("選項1", a);

                                firebaseFirestore.collection("vote").document(voteId).update(vote).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            Toast.makeText(VotePage2.this, "voted succesfully", Toast.LENGTH_LONG).show();


                                        }
                                    }
                                });
                                firebaseFirestore.collection("users").document(userID).collection("vote").document(voteId).set(vote).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            //Toast.makeText(VotePage.this, "voted succesfully", Toast.LENGTH_LONG).show();


                                        }
                                    }
                                });
                            }
                        });

                builder1.setNegativeButton(
                        "No",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });

                AlertDialog alert11 = builder1.create();
                alert11.show();

            }

        });
        button_B.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                docRef2.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                            if (document.exists()) {
                                Log.d("TAG", "DocumentSnapshot data: " + document.getData());
                                AlertDialog.Builder builder1 = new AlertDialog.Builder(VotePage2.this);
                                builder1.setMessage("您已投過該投票");
                                builder1.setCancelable(true);

                                builder1.setPositiveButton(
                                        "確定返回",
                                        new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                dialog.cancel();
                                                startActivity(new Intent(VotePage2.this, VoteMain.class));

                                            }
                                        });


                                AlertDialog alert11 = builder1.create();
                                alert11.show();

                            }
                        } else {
                            Log.d("TAG", "No such document");
                        }
                    }

                });

                AlertDialog.Builder builder1 = new AlertDialog.Builder(VotePage2.this);
                builder1.setMessage("確定投下"+bv+"嗎?"+" 一經投票不可更改.");
                builder1.setCancelable(true);

                builder1.setPositiveButton(
                        "Yes",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();

                                Map<String, Object> vote = new HashMap<>();
                                b++;
                                vote.put("選項2", b);

                                firebaseFirestore.collection("vote").document(voteId).update(vote).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            Toast.makeText(VotePage2.this, "voted succesfully", Toast.LENGTH_LONG).show();


                                        }
                                    }
                                });
                                firebaseFirestore.collection("users").document(userID).collection("vote").document(voteId).set(vote).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            //Toast.makeText(VotePage.this, "voted succesfully", Toast.LENGTH_LONG).show();


                                        }
                                    }
                                });
                            }
                        });

                builder1.setNegativeButton(
                        "No",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });

                AlertDialog alert11 = builder1.create();
                alert11.show();

            }

        });
        button_C.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(cv.isEmpty()){
                    Toast.makeText(VotePage2.this, "請投下正確的內容", Toast.LENGTH_SHORT).show();
                }else{
                    docRef2.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                            if (task.isSuccessful()) {
                                DocumentSnapshot document = task.getResult();
                                if (document.exists()) {
                                    Log.d("TAG", "DocumentSnapshot data: " + document.getData());
                                    AlertDialog.Builder builder1 = new AlertDialog.Builder(VotePage2.this);
                                    builder1.setMessage("您已投過該投票");
                                    builder1.setCancelable(true);

                                    builder1.setPositiveButton(
                                            "確定返回",
                                            new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int id) {
                                                    dialog.cancel();
                                                    startActivity(new Intent(VotePage2.this, VoteMain.class));

                                                }
                                            });


                                    AlertDialog alert11 = builder1.create();
                                    alert11.show();

                                }
                            } else {
                                Log.d("TAG", "No such document");
                            }
                        }

                    });

                    AlertDialog.Builder builder1 = new AlertDialog.Builder(VotePage2.this);
                    builder1.setMessage("確定投下"+cv+"嗎?"+" 一經投票不可更改.");
                    builder1.setCancelable(true);

                    builder1.setPositiveButton(
                            "Yes",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();

                                    Map<String, Object> vote = new HashMap<>();
                                    c++;
                                    vote.put("選項3", c);

                                    firebaseFirestore.collection("vote").document(voteId).update(vote).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()) {
                                                Toast.makeText(VotePage2.this, "voted succesfully", Toast.LENGTH_LONG).show();


                                            }
                                        }
                                    });
                                    firebaseFirestore.collection("users").document(userID).collection("vote").document(voteId).set(vote).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()) {
                                                //Toast.makeText(VotePage.this, "voted succesfully", Toast.LENGTH_LONG).show();


                                            }
                                        }
                                    });
                                }
                            });

                    builder1.setNegativeButton(
                            "No",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                }
                            });

                    AlertDialog alert11 = builder1.create();
                    alert11.show();
                }


            }

        });
        button_D.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(dv.isEmpty()){
                    Toast.makeText(VotePage2.this, "請投下正確的內容", Toast.LENGTH_SHORT).show();
                }else{
                    docRef2.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                            if (task.isSuccessful()) {
                                DocumentSnapshot document = task.getResult();
                                if (document.exists()) {
                                    Log.d("TAG", "DocumentSnapshot data: " + document.getData());
                                    AlertDialog.Builder builder1 = new AlertDialog.Builder(VotePage2.this);
                                    builder1.setMessage("您已投過該投票");
                                    builder1.setCancelable(true);

                                    builder1.setPositiveButton(
                                            "確定返回",
                                            new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int id) {
                                                    dialog.cancel();
                                                    startActivity(new Intent(VotePage2.this, VoteMain.class));

                                                }
                                            });


                                    AlertDialog alert11 = builder1.create();
                                    alert11.show();

                                }
                            } else {
                                Log.d("TAG", "No such document");
                            }
                        }

                    });

                    AlertDialog.Builder builder1 = new AlertDialog.Builder(VotePage2.this);
                    builder1.setMessage("確定投下"+dv+"嗎?"+" 一經投票不可更改.");
                    builder1.setCancelable(true);

                    builder1.setPositiveButton(
                            "Yes",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();

                                    Map<String, Object> vote = new HashMap<>();
                                    d++;
                                    vote.put("選項4",d);

                                    firebaseFirestore.collection("vote").document(voteId).update(vote).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()) {
                                                Toast.makeText(VotePage2.this, "voted succesfully", Toast.LENGTH_LONG).show();


                                            }
                                        }
                                    });
                                    firebaseFirestore.collection("users").document(userID).collection("vote").document(voteId).set(vote).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()) {
                                                //Toast.makeText(VotePage.this, "voted succesfully", Toast.LENGTH_LONG).show();


                                            }
                                        }
                                    });
                                }
                            });

                    builder1.setNegativeButton(
                            "No",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                }
                            });

                    AlertDialog alert11 = builder1.create();
                    alert11.show();
                }


            }

        });





    }
}
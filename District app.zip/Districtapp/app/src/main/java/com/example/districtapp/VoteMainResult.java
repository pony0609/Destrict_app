package com.example.districtapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;

public class VoteMainResult extends AppCompatActivity implements Serializable {
    Button button7;
    TextView rs;
    ListView lv1;
    ArrayList<itemAnnounce> ar = new ArrayList<>();
    String userID, idlv, type;
    FirebaseAuth firebaseAuth;
    FirebaseFirestore firebaseFirestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.vote_listview_result);
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();
        userID = firebaseAuth.getCurrentUser().getUid();

        button7 = findViewById(R.id.button7);
        rs = findViewById(R.id.textView21);

        firebaseFirestore.collection("vote").whereNotEqualTo("result","").orderBy("result").orderBy("createdAt", Query.Direction.DESCENDING).addSnapshotListener((documentSnapshots, error) -> {
            ar.clear();

            for (DocumentSnapshot snapshot : documentSnapshots) {
                idlv = snapshot.getId();
                Timestamp timestamp = (Timestamp) snapshot.getData().get("createdAt");
                Date date = timestamp.toDate();
                String date2 = date.toString();

                type = snapshot.getString("vote_option");

                ar.add(new itemAnnounce(R.drawable.vote123, snapshot.getString("vote_title"), "by " + snapshot.getString("createdBy"), date2, snapshot.getString("vote_content"), idlv, type));

            }
            adapterAnnounce adapterAnnounce = new adapterAnnounce(getApplicationContext(), R.layout.list_row_announce, ar);
            adapterAnnounce.notifyDataSetChanged();
            lv1.setAdapter(adapterAnnounce);

            lv1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Object selectedObj = adapterAnnounce.getItem(position).getId();// this will get you selected obj of itemAnnounce
                    String obj = (String) selectedObj.toString();


                    Intent i = new Intent(VoteMainResult.this, VoteResultPage.class);
                    i.putExtra("voteId", obj);
                   startActivity(i);

                }
            });
        });
        lv1 = findViewById(R.id.lv2);

        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(VoteMainResult.this, VoteMain.class));
            }
        });

        rs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(VoteMainResult.this, VoteMain.class));
            }
        });


    }


}

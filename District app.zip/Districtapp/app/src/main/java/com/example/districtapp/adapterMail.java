package com.example.districtapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class adapterMail extends ArrayAdapter<itemMail> {
    private Context mContext;
    private int mResource;
    public adapterMail(@NonNull Context context, int resource,@NonNull ArrayList<itemMail> objects) {
        super(context, resource,objects);
        this.mContext=context;
        this.mResource=resource;
    }
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(mContext);
        convertView = layoutInflater.inflate(mResource,parent,false);
        ImageView imageView = convertView.findViewById(R.id.image);
        TextView txtName = convertView.findViewById(R.id.txtName);
        TextView txtAdmin = convertView.findViewById(R.id.txtAdmin);
        TextView txtTime = convertView.findViewById(R.id.txtTime);
        TextView txtend = convertView.findViewById(R.id.txtend);
        TextView txtaccept = convertView.findViewById(R.id.txtaccept);
        imageView.setImageResource(getItem(position).getImage());
        txtName.setText(getItem(position).getName());
        txtAdmin.setText(getItem(position).getAdmin());
        txtTime.setText(getItem(position).getTime());
        txtend.setText(getItem(position).getEnd());
        txtaccept.setText(getItem(position).getAccept());
        return convertView;
    }

}

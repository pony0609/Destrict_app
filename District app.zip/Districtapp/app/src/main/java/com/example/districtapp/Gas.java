package com.example.districtapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

public class Gas extends AppCompatActivity {
    ArrayList<item2> ar = new ArrayList<>();
    private FirebaseAuth firebaseAuth;
    ListView lv4;
    FirebaseFirestore firebaseFirestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gas_activity);
        Button btGoSave;
        btGoSave = findViewById(R.id.button_GoSave);
        lv4 = findViewById(R.id.lv4);
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();
        firebaseFirestore.collection("utilities").addSnapshotListener((documentSnapshots, error) -> {
            ar.clear();
            for (DocumentSnapshot snapshot : documentSnapshots) {

                ar.add(new item2(snapshot.getString("time"), snapshot.getString("gree")));
            }
            adapter3 adapter3 = new adapter3(getApplicationContext(), R.layout.list_row_gas, ar);
            adapter3.notifyDataSetChanged();
            lv4.setAdapter(adapter3);
        });


        btGoSave.setOnClickListener(v -> {
            Intent intent = new Intent(Gas.this, GasData.class);
            startActivity(intent);
        });


    }


}
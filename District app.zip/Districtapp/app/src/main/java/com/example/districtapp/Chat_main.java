package com.example.districtapp;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Chat_main extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_main1);
    }
}

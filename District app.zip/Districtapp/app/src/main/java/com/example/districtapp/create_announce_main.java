package com.example.districtapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class create_announce_main extends AppCompatActivity {
    EditText art1, art2;
    Button send, button2, clear;
    ArrayList<item> ar = new ArrayList<>();

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_announce);
        art1 = findViewById(R.id.art1);
        art2 = findViewById(R.id.art2);
        send = findViewById(R.id.send);
        clear = findViewById(R.id.clear);
        button2 = findViewById(R.id.button2);
        loadData();

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = art1.getText().toString();
                String content = art2.getText().toString();

                ar.add(new item(R.drawable.ann3, title, content));
                Intent intent = new Intent(create_announce_main.this, announce_main.class);
                savedata();
                intent.putExtra("record", ar);
                startActivity(intent);


            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(create_announce_main.this, announce_main.class);
                intent.putExtra("record", ar);
                startActivity(intent);
            }
        });
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ar.clear();
            }
        });


    }

    private void savedata() {
        SharedPreferences sharedPreferences = getSharedPreferences("arr", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(ar);
        editor.putString("task list", json);
        editor.apply();
    }

    private void loadData() {
        SharedPreferences sharedPreferences = getSharedPreferences("arr", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("task list", null);
        Type type = new TypeToken<ArrayList<item>>() {
        }.getType();
        ar = gson.fromJson(json, type);
        if (ar == null) {
            ar = new ArrayList<>();
        }
    }
}

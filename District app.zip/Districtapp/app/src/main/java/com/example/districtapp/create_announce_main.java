package com.example.districtapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class create_announce_main extends AppCompatActivity {
    String userID,recID,name;
    private FirebaseAuth firebaseAuth;
    FirebaseFirestore firebaseFirestore;
    EditText art1, art2;
    Button send, button7;
    ArrayList<item> ar = new ArrayList<>();

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_announce);
        art1 = findViewById(R.id.art1);
        art2 = findViewById(R.id.art2);
        send = findViewById(R.id.send);

        button7 = findViewById(R.id.button7);
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();
        //  loadData();
        userID = firebaseAuth.getCurrentUser().getUid();
        DocumentReference docRef = firebaseFirestore.collection("users").document(userID);
        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Log.d("TAG", "DocumentSnapshot data: " + document.getData());
                        recID = document.getString("recID");
                        name = document.getString("user_name");
                    } else {
                        Log.d("TAG", "No such document");
                    }
                } else {
                    Log.d("TAG", "get failed with ", task.getException());
                }
            }
        });
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.getId();
                String title = art1.getText().toString();
                String content = art2.getText().toString();


                Intent intent = new Intent(create_announce_main.this, SuggestionMain.class);

                //  DocumentReference documentReference = firebaseFirestore.collection("announce").document("ann");
                Map<String, Object> suggest = new HashMap<>();
                suggest.put("title", title);
                suggest.put("content", content);
                suggest.put("name", name);
                suggest.put("recID", recID);
                suggest.put("admin_name", "");
                suggest.put("response_content", "");
                suggest.put("response_status", "未回覆");
                suggest.put("response_time",FieldValue.serverTimestamp());
                suggest.put("createdAt", FieldValue.serverTimestamp());
                firebaseFirestore.collection("Suggestion").document().set(suggest).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(create_announce_main.this, "added succesfully", Toast.LENGTH_LONG).show();


                        }
                    }
                });

                startActivity(intent);


            }
        });
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(create_announce_main.this,SuggestionMain.class);
                startActivity(intent);
            }
        });


    }

}

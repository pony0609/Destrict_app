package com.example.districtapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class create_announce_main extends AppCompatActivity {
    String userID;
    private FirebaseAuth firebaseAuth;
    FirebaseFirestore firebaseFirestore;
    EditText art1, art2;
    Button send, button2;
    ArrayList<item> ar = new ArrayList<>();

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_announce);
        art1 = findViewById(R.id.art1);
        art2 = findViewById(R.id.art2);
        send = findViewById(R.id.send);

        button2 = findViewById(R.id.button2);
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();
      //  loadData();

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = art1.getText().toString();
                String content = art2.getText().toString();


                Intent intent = new Intent(create_announce_main.this, announce_main.class);
                userID = firebaseAuth.getCurrentUser().getUid();
                //  DocumentReference documentReference = firebaseFirestore.collection("announce").document("ann");
                Map<String, Object> announce = new HashMap<>();
                announce.put("title", title);
                announce.put("content", content);
                firebaseFirestore.collection("announcement").document().set(announce).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(create_announce_main.this, "added succesfully", Toast.LENGTH_LONG).show();
                        }
                    }
                });

                startActivity(intent);


            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(create_announce_main.this, announce_main.class);
                startActivity(intent);
            }
        });



    }

    /*private void savedata() {
        SharedPreferences sharedPreferences = getSharedPreferences("arr", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(ar);
        editor.putString("task list", json);
        editor.apply();
    }

    private void loadData() {
        SharedPreferences sharedPreferences = getSharedPreferences("arr", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("task list", null);
        Type type = new TypeToken<ArrayList<item>>() {
        }.getType();
        ar = gson.fromJson(json, type);
        if (ar == null) {
            ar = new ArrayList<>();
        }
    }*/
}

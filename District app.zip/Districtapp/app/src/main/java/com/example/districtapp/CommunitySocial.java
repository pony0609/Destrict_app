package com.example.districtapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class CommunitySocial extends AppCompatActivity {
    Button button17,button18;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.communitysocial);
        button17 = findViewById(R.id.button17);
        button17.setOnClickListener(this::onClick);
        button18 = findViewById(R.id.button18);
        button18.setOnClickListener(this::onClick);


    }
    public void onClick(View v) {

        switch(v.getId()) {
            case R.id.button17:
                Intent intent = new Intent(CommunitySocial.this, HomePageActivity.class);
                startActivity(intent);
                break;
            case R.id.button18:
                Intent intent2 = new Intent(CommunitySocial.this, VoteMain.class);
                startActivity(intent2);
                break;




        }


    }


}

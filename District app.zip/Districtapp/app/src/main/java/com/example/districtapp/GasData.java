package com.example.districtapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;

public class GasData extends AppCompatActivity {
    FirebaseAuth firebaseAuth;
    FirebaseFirestore firebaseFirestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gasdata_activity);

        EditText editText = findViewById(R.id.editText_Input);
        Button btSaved = findViewById(R.id.button_Save);
        // Date currentTime = Calendar.getInstance().getTime();
        // DateFormat df = new SimpleDateFormat("EEE, d MMM yyyy, HH:mm");
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();

// you can get seconds by adding  "...:ss" to it



        btSaved.setOnClickListener(v -> {
            String ret = editText.getText().toString();
            Calendar calendar = Calendar.getInstance();
            SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss");
            sdf.setTimeZone(TimeZone.getTimeZone("GMT 8"));
            String rt = sdf.format(calendar.getTime());

            if (ret.isEmpty()) {
                Toast.makeText(this, "未輸入資料..", Toast.LENGTH_SHORT).show();
            } else {
                Intent intent = new Intent(GasData.this, Gas.class);
                Map<String, Object> utilities = new HashMap<>();
                utilities.put("time", rt);
                utilities.put("gree", ret+"度");
                firebaseFirestore.collection("utilities").document().set(utilities).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(GasData.this, "added succesfully", Toast.LENGTH_LONG).show();
                            startActivity(intent);

                        }
                    }
                });


            }


        });


    }

}
package com.example.districtapp;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Source;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Year;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;

public class GasData extends AppCompatActivity {
    FirebaseAuth firebaseAuth;
    FirebaseFirestore firebaseFirestore;
    Button button7, button8;
    String userID, key, ID, yrs, mons, gree;
    int year, month;
    TextView textView37, textView38;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gasdata_activity);
        button7 = findViewById(R.id.button7);
        button8 = findViewById(R.id.button8);
        textView37 = findViewById(R.id.textView37);
        textView38 = findViewById(R.id.textView38);
        EditText editText = findViewById(R.id.editText_Input);
        Button btSaved = findViewById(R.id.button_Save);
        // Date currentTime = Calendar.getInstance().getTime();
        // DateFormat df = new SimpleDateFormat("EEE, d MMM yyyy, HH:mm");
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();
        userID = firebaseAuth.getCurrentUser().getUid();
        Calendar calendar2 = Calendar.getInstance();
        year = calendar2.get(Calendar.YEAR);
        month = calendar2.get(Calendar.MONTH) + 1;
        yrs = String.valueOf(year);
        mons = String.valueOf(month);
        textView38.setText(mons);


        DocumentReference documentReference = firebaseFirestore.collection("users").document(userID);
        documentReference.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                DocumentSnapshot document = task.getResult();
                key = document.getString("recID");
                ID = key + "-" + yrs + "-" + mons;
                DocumentReference documentReference2 = firebaseFirestore.collection("utilities").document(ID.toString());
                documentReference2.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        DocumentSnapshot document = task.getResult();
                        gree = document.getString("gree");
                        textView37.setText(gree);
                    }
                });
            }
        });


        btSaved.setOnClickListener(v -> {
            String ret = editText.getText().toString();
            Calendar calendar = Calendar.getInstance();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");
            sdf.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
            String rt = sdf.format(calendar.getTime());

            if (ret.isEmpty()) {
                Toast.makeText(this, "未輸入資料..", Toast.LENGTH_SHORT).show();
            } else {
                Intent intent = new Intent(GasData.this, Gas.class);
                Map<String, Object> utilities = new HashMap<>();
                utilities.put("time", rt);
                utilities.put("gree", ret + "度");
                utilities.put("recID", key);
                utilities.put("month", mons);
                firebaseFirestore.collection("utilities").document(ID.toString()).set(utilities).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(GasData.this, "added succesfully", Toast.LENGTH_LONG).show();
                            startActivity(new Intent(GasData.this, GasData.class));
                        }
                    }
                });
                firebaseFirestore.collection("users").document(userID).collection("utilities").document(ID.toString()).set(utilities).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(GasData.this, "added succesfully", Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }

        });
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(GasData.this, CommunityDaily.class));
            }
        });

        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(GasData.this, Gas.class));
            }
        });

    }

}
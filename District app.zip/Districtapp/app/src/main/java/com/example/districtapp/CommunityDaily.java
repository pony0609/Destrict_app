package com.example.districtapp;

import android.app.SearchManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class CommunityDaily extends AppCompatActivity {
    Button button7,button9,button11,button13,button8,button100,button12,button10,button16,button15;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.communitydaily);
        button7 = findViewById(R.id.button7);

        button9 = findViewById(R.id.button9);
        button15 = findViewById(R.id.button15);
        button13 = findViewById(R.id.button13);
        button12 = findViewById(R.id.button12);

        button11 = findViewById(R.id.button11);

        button8 = findViewById(R.id.button8);
        button10 = findViewById(R.id.button10);
        button100 = findViewById(R.id.button100);
        button12 = findViewById(R.id.button12);
        button16 = findViewById(R.id.button16);
        button100.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(CommunityDaily.this,VisitorMain.class));
            }
        });
        button11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(CommunityDaily.this,mail.class));
            }
        });
        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(CommunityDaily.this,announce_main.class));
            }
        });
        button13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(CommunityDaily.this,TaxiMain.class));
            }
        });
        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(CommunityDaily.this,ConventMain.class));
            }
        });
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(CommunityDaily.this,HomePageActivity.class));
            }
        });
        button10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(CommunityDaily.this,SuggestionMain.class));
            }
        });
        button16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(CommunityDaily.this,FeePage1.class));
            }
        });
        button15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(CommunityDaily.this,GasData.class));
            }
        });
        button12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(CommunityDaily.this,EquipMain.class));
            }
        });

    }






}

package com.example.districtapp;

import com.google.firebase.firestore.Exclude;

import java.io.Serializable;

public class itemAnnounce implements Serializable {
    @Exclude
    private String id;
    String option;
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }

    public int getImage() {
        return image;
    }
    public void setImage(int image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getDes() {
        return Des;
    }
    public void setDes(String des) {
        Des = des;
    }

    public String getAdmin() {
        return admin;
    }
    public void setAdmin(String admin) {
        this.admin = admin;
    }

    public String getTime() {
        return time;
    }
    public void setTime(String time) {
        this.time = time;
    }

    public String getOption() {
        return option;
    }
    public void setOption(String option) {
        this.option = option;
    }

    int image;
    String name;
    String Des;
    String admin;
    String time;
    public itemAnnounce(int image, String name, String admin,String time,String des,String id,String option) {
        this.image = image;
        this.name = name;
        this.admin = admin;
        this.time = time;
        this.id = id;
        this.option = option;
        Des = des;
    }


}
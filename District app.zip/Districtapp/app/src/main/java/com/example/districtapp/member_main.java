package com.example.districtapp;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

public class member_main extends AppCompatActivity {
    ListView lv;
    ArrayList<item> ar = new ArrayList<>();
    FirebaseAuth firebaseAuth;
    FirebaseFirestore firebaseFirestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //final ArrayList<item> ar = (ArrayList<item>) getIntent().getExtras().getSerializable("record");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.listview);
        lv = findViewById(R.id.lv);
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();
        firebaseFirestore.collection("members").addSnapshotListener((documentSnapshots, error) -> {
            ar.clear();
            for (DocumentSnapshot snapshot : documentSnapshots) {
                //item item = snapshot.toObject(item.class);
                // item.setId(snapshot.getId());
                ar.add(new item(R.drawable.person1, snapshot.getString("name"), snapshot.getString("description")));
            }
            adapter2 adapter2 = new adapter2(getApplicationContext(), R.layout.list_row, ar);
            adapter2.notifyDataSetChanged();
            lv.setAdapter(adapter2);
        });




    }

}

package com.example.districtapp;

import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class member_main extends AppCompatActivity {
    ListView lv;
    ArrayList<item> ar = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //final ArrayList<item> ar = (ArrayList<item>) getIntent().getExtras().getSerializable("record");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.listview);
        lv = findViewById(R.id.lv);
        ar.add(new item(R.drawable.person1,"人員1","Member1111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111"));
        ar.add(new item(R.drawable.person1,"人員2","Member22222"));
        ar.add(new item(R.drawable.person1,"人員3","Member33333"));
        ar.add(new item(R.drawable.person1,"人員4","Member44444"));
        ar.add(new item(R.drawable.person1,"人員5","Member55555"));
        ar.add(new item(R.drawable.person1,"人員6","Member66666"));
        ar.add(new item(R.drawable.person1,"人員7","Member77777"));
        ar.add(new item(R.drawable.person1,"人員8","Member88888"));
        ar.add(new item(R.drawable.person1,"人員9","Member99999"));
        ar.add(new item(R.drawable.person1,"人員10","Member33333"));
        ar.add(new item(R.drawable.person1,"人員11","Member33333"));
        ar.add(new item(R.drawable.person1,"人員12","Member33333"));
        ar.add(new item(R.drawable.person1,"人員13","Member33333"));
        adapter2 adapter2 = new adapter2(this, R.layout.list_row, ar);
        lv.setAdapter(adapter2);

    }

}

package com.example.districtapp;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class member_main extends AppCompatActivity {
    ListView lv;
    ArrayList<item> ar = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //final ArrayList<item> ar = (ArrayList<item>) getIntent().getExtras().getSerializable("record");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.listview);
        lv = findViewById(R.id.lv);
        ar.add(new item(R.drawable.person1,"人員1","Member1111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111"));
        ar.add(new item(R.drawable.person1,"人員2","Member22222"));
        ar.add(new item(R.drawable.person1,"人員3","Member33333"));
        ar.add(new item(R.drawable.person1,"人員4","Member44444"));
        ar.add(new item(R.drawable.person1,"人員5","Member55555"));
        ar.add(new item(R.drawable.person1,"人員6","Member66666"));
        ar.add(new item(R.drawable.person1,"人員7","Member77777"));
        ar.add(new item(R.drawable.person1,"人員8","Member88888"));
        ar.add(new item(R.drawable.person1,"人員9","Member99999"));
        ar.add(new item(R.drawable.person1,"人員10","Member33333"));
        ar.add(new item(R.drawable.person1,"人員11","Member33333"));
        ar.add(new item(R.drawable.person1,"人員12","Member33333"));
        ar.add(new item(R.drawable.person1,"人員13","Member33333"));
        final adapter2 adapter2 = new adapter2(this, R.layout.list_row, ar);
        lv.setAdapter(adapter2);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                AlertDialog.Builder builder = new AlertDialog.Builder(member_main.this);
                builder.setMessage("是否確定刪除");
                builder.setPositiveButton("yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        ar.remove(position);
                        adapter2.notifyDataSetChanged();
                    }
                });
                builder.setNegativeButton("no", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int id) {

                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

    }

}

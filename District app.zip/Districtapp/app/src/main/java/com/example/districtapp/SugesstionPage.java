package com.example.districtapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Date;

public class SugesstionPage extends AppCompatActivity {
    String userID,annId;
    TextView name,name2,date1,date3,title1,title2,content1,content2,ss,sss;
    Button button7;
    FirebaseAuth firebaseAuth;
    FirebaseFirestore firebaseFirestore;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.suggestion_page);
        name = findViewById(R.id.textView24);
        name2 = findViewById(R.id.textView31);
        date3 = findViewById(R.id.textView33);
        title1 = findViewById(R.id.textView28);
        title2 = findViewById(R.id.textView34);
        content1 = findViewById(R.id.textView29);
        content2 = findViewById(R.id.textView35);
        date1 = findViewById(R.id.textView26);
        button7 = findViewById(R.id.button7);
        ss = findViewById(R.id.textView30);
        sss = findViewById(R.id.textView32);
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();
        userID = firebaseAuth.getCurrentUser().getUid();
        if (savedInstanceState == null) {
            Bundle extras = getIntent().getExtras();
            if (extras == null) {
                annId = null;
            } else {
                annId = extras.getString("annId");
            }
        } else {
            annId = (String) savedInstanceState.getSerializable("annId");
        }


        DocumentReference docRef = firebaseFirestore.collection("Suggestion").document(annId);
        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Log.d("TAG", "DocumentSnapshot data: " + document.getData());
                        if(document.getString("response_status").equals("未回覆")){
                            Timestamp timestamp = (Timestamp) document.getData().get("createdAt");
                            Date date = timestamp.toDate();
                            String date2 = date.toString();
                            date1.setText(date2);
                            name.setText(document.getString("name"));
                            title1.setText(document.getString("title"));
                            content1.setText(document.getString("content"));
                            ss.setVisibility(View.INVISIBLE);
                            name2.setVisibility(View.INVISIBLE);
                            sss.setVisibility(View.INVISIBLE);
                            date3.setVisibility(View.INVISIBLE);
                            title2.setVisibility(View.INVISIBLE);
                            content2.setVisibility(View.INVISIBLE);
                        }else{
                            Timestamp timestamp = (Timestamp) document.getData().get("createdAt");
                            Date date = timestamp.toDate();
                            String date2 = date.toString();
                            date1.setText(date2);
                            name.setText(document.getString("name"));
                            title1.setText(document.getString("title"));
                            content1.setText(document.getString("content"));
                            Timestamp timestamp2 = (Timestamp) document.getData().get("response_time");
                            Date date4 = timestamp2.toDate();
                            String date5 = date4.toString();
                            date3.setText(date5);
                            name2.setText(document.getString("name"));
                            title2.setText(document.getString("admin_name"));
                            content2.setText(document.getString("response_content"));
                        }



                    } else {
                        Log.d("TAG", "No such document");
                    }
                } else {
                    Log.d("TAG", "get failed with ", task.getException());
                }


            }
        });
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SugesstionPage.this, SuggestionMain.class));
            }
        });



    }
}

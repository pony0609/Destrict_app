package com.example.districtapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class EQreportPage extends AppCompatActivity implements AdapterView.OnItemSelectedListener {


    Uri imageUri;
    ImageView piceq;
    StorageReference storageReference;
    ProgressDialog progressDialog;
    Button button7,imagebut,send;
    EditText edit1,edit2,content;
    FirebaseStorage firebaseStorage;
    FirebaseAuth firebaseAuth;
    FirebaseFirestore firebaseFirestore;
    String userID,spinVar,fileName,recID,name,phone,email,ImageUrl;
    Spinner rpspin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.eqreportpage);
        button7 = findViewById(R.id.button7);
        edit1 = findViewById(R.id.edit1);
        edit2 = findViewById(R.id.edit2);
        content = findViewById(R.id.editTextTextMultiLine);
        imagebut = findViewById(R.id.button26);
        send = findViewById(R.id.button27);
        rpspin = findViewById(R.id.spinner);
        piceq = findViewById(R.id.imageView10);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(EQreportPage.this,R.array.reportEQ, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        rpspin.setAdapter(adapter);
        rpspin.setOnItemSelectedListener(EQreportPage.this);
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();
        userID = firebaseAuth.getCurrentUser().getUid();

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss", Locale.TAIWAN);
        Date now = new Date();
        fileName = formatter.format(now);

        DocumentReference docRef = firebaseFirestore.collection("users").document(userID);
        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Log.d("TAG", "DocumentSnapshot data: " + document.getData());
                        recID = document.getString("recID");
                        name = document.getString("user_name");
                        email = document.getString("email");
                        phone = document.getString("phone");
                    } else {
                        Log.d("TAG", "No such document");
                    }
                } else {
                    Log.d("TAG", "get failed with ", task.getException());
                }
            }
        });

        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(EQreportPage.this,MyEQreport.class));
            }
        });
        imagebut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectImage();
            }
        });
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                v.getId();
                String place = edit1.getText().toString();
                String reason = edit2.getText().toString();
                String content1 = content.getText().toString();

                if(place.isEmpty() | reason.isEmpty()){
                    Toast.makeText(EQreportPage.this, "請輸入必要資訊", Toast.LENGTH_LONG).show();
                }else{
                    Intent intent = new Intent(EQreportPage.this, MyEQreport.class);
                    uploadImage();
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Map<String, Object> eqr = new HashMap<>();
                            eqr.put("email", email);
                            eqr.put("recID", recID);
                            eqr.put("phone", phone);
                            eqr.put("報修地點", place);
                            eqr.put("申報事由", reason);
                            eqr.put("申報項目", spinVar);
                            eqr.put("狀態", "待處理");
                            eqr.put("說明", content1);
                            eqr.put("照片",ImageUrl);
                            eqr.put("createdAt", FieldValue.serverTimestamp());
                            firebaseFirestore.collection("equipmentReport").document().set(eqr).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {
                                        Toast.makeText(EQreportPage.this, "added succesfully", Toast.LENGTH_LONG).show();


                                    }
                                }
                            });
                        }
                    }, 2000);

                    //  DocumentReference documentReference = firebaseFirestore.collection("announce").document("ann");


                    startActivity(intent);
                }



            }
        });
    }

    private void selectImage() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent,100);
    }
    private void uploadImage() {
        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Uploading File....");
        progressDialog.show();



        storageReference = FirebaseStorage.getInstance().getReference("images/"+fileName);



        storageReference.putFile(imageUri)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        storageReference.getDownloadUrl().addOnCompleteListener(new OnCompleteListener<Uri>() {
                            @Override
                            public void onComplete(@NonNull Task<Uri> task) {
                                ImageUrl=task.getResult().toString();
                                Log.i("URL",ImageUrl);
                            }
                        });
                        piceq.setImageURI(null);
                        Toast.makeText(EQreportPage.this,"Successfully Uploaded",Toast.LENGTH_SHORT).show();
                        if (progressDialog.isShowing())
                            progressDialog.dismiss();

                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {


                if (progressDialog.isShowing())
                    progressDialog.dismiss();
                Toast.makeText(EQreportPage.this,"Failed to Upload Picture",Toast.LENGTH_SHORT).show();


            }
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        spinVar = parent.getItemAtPosition(position).toString();

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 100 && data != null && data.getData() != null){

            imageUri = data.getData();
            piceq.setImageURI(imageUri);



        }
    }
}


package com.example.districtapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.io.Serializable;
import java.util.ArrayList;

public class VoteResultPage extends AppCompatActivity implements Serializable {
    Button button_A,button_B,button7,button_C,button_D;
    TextView vote_title,vote_create,vote_start,vote_end,vote_content;
    FirebaseAuth firebaseAuth;
    FirebaseFirestore firebaseFirestore;
    String voteId,userID,av,bv,cv,dv,result;
    ListView lv2;
    int a,b,c,d;
    ArrayList<item2> ar = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.vote_page2);
        button7 = findViewById(R.id.button7);
        button_A = findViewById(R.id.button);
        button_B = findViewById(R.id.button24);
        button_C = findViewById(R.id.button22);
        button_D = findViewById(R.id.button23);
        vote_title = findViewById(R.id.textView7);
        vote_create = findViewById(R.id.textView8);
        vote_start = findViewById(R.id.textView9);
        vote_end = findViewById(R.id.textView10);
        vote_content = findViewById(R.id.textView11);
        lv2 = findViewById(R.id.lv2);
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();
        userID = firebaseAuth.getCurrentUser().getUid();

        if (savedInstanceState == null) {
            Bundle extras = getIntent().getExtras();
            if (extras == null) {
                voteId = null;
            } else {
                voteId = extras.getString("voteId");
            }
        } else {
            voteId = (String) savedInstanceState.getSerializable("voteId");
        }

        DocumentReference docRef = firebaseFirestore.collection("vote").document(voteId);
        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Log.d("TAG", "DocumentSnapshot data: " + document.getData());
                        vote_title.setText(document.getString("vote_title"));
                        vote_create.setText(document.getString("createdBy"));
                        vote_start.setText(document.getString("start_time"));
                        vote_end.setText(document.getString("end_time"));
                        vote_content.setText(document.getString("vote_content"));
                        av = document.getString("A");
                        bv = document.getString("B");
                        cv = document.getString("C");
                        dv = document.getString("D");
                        result = document.getString("result");
                        if (cv.equals("")) {


                            button_C.setVisibility(View.INVISIBLE);
                            button_D.setVisibility(View.INVISIBLE);

                        }else if(!cv.equals("") && dv.equals("")){
                            button_D.setVisibility(View.INVISIBLE);
                        }else{

                        }

                        AlertDialog.Builder builder1 = new AlertDialog.Builder(VoteResultPage.this);
                        builder1.setMessage("投票結果為  " + result + "，如有問題請洽管理室");
                        builder1.setCancelable(true);

                        builder1.setPositiveButton(
                                "確定返回已結束投票清單",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        dialog.cancel();
                                        startActivity(new Intent(VoteResultPage.this, VoteMainResult.class));

                                    }
                                });


                        AlertDialog alert11 = builder1.create();
                        alert11.show();
                        button_A.setText(document.getString("A"));
                        button_B.setText(document.getString("B"));
                        button_C.setText(document.getString("C"));
                        button_D.setText(document.getString("D"));
                        ar.add(new item2(document.getString("vote_title"), document.getString("vote_description")));


                    } else {
                        Log.d("TAG", "No such document");
                    }
                } else {
                    Log.d("TAG", "get failed with ", task.getException());
                }
                adapter3 adapter3 = new adapter3(getApplicationContext(), R.layout.list_row_convent, ar);
                adapter3.notifyDataSetChanged();
                lv2.setAdapter(adapter3);
            }
        });
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(VoteResultPage.this, VoteMainResult.class));
            }
        });
    }
}

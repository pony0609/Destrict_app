package com.example.districtapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.jar.Attributes;

public class MainActivity extends AppCompatActivity {
    EditText email, password;
    TextView login, register, forgotpass;
    ImageView twitt, insta, fb;
    Button loginb;
    private FirebaseAuth firebaseAuth;
    private ProgressDialog progressDialog;
    private int counter = 5;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        loginb = findViewById(R.id.loginb);
        register = findViewById(R.id.register);
        forgotpass = findViewById(R.id.forgotpass);
        firebaseAuth = FirebaseAuth.getInstance();
        twitt = findViewById(R.id.twitt);
        insta = findViewById(R.id.insta);
        fb = findViewById(R.id.fb);
        progressDialog = new ProgressDialog(this);
        FirebaseUser usercheck = firebaseAuth.getCurrentUser();



        /*if(usercheck != null){
            finish();
            startActivity(new Intent(MainActivity.this,HomePageActivity.class));
        }*/ //檢測使用者是否已經有登入帳號 有就直接進HOMEPAGE

        loginb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String useremail = email.getText().toString();
                String userpass = password.getText().toString();

                if (useremail.matches("") || userpass.matches("")) {
                    Toast.makeText(MainActivity.this, "Please enter name and password!", Toast.LENGTH_LONG).show();
                } else {
                    validate(email.getText().toString(), password.getText().toString());
                }
            }
        });

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, register_main.class));
            }
        });
        forgotpass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, passwordActivity.class));
            }
        });
        twitt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse("https://twitter.com/?lang=zh-tw");
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }
        });
        insta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse("https://www.instagram.com");
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }
        });
        fb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse("https://www.facebook.com");
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }
        });

    }


    private void validate(String Email, String userPassword) {
        progressDialog.setMessage("system directing to the server");
        progressDialog.show();
        firebaseAuth.signInWithEmailAndPassword(Email, userPassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    progressDialog.dismiss();
                    Toast.makeText(MainActivity.this, "Login succesful", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(new Intent(MainActivity.this, HomePageActivity.class));
                    startActivity(intent);

                } else {
                    Toast.makeText(MainActivity.this, "Login failed", Toast.LENGTH_SHORT).show();
                    counter--;
                    if (counter == 0) {
                        login.setEnabled(false);
                        Toast.makeText(MainActivity.this, "You have used all your attempts try again later!", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });

    }
}
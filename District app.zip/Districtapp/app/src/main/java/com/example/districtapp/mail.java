package com.example.districtapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;


public class mail extends AppCompatActivity {
    Button button7,button8;
    ListView lv1,lv3;
    TextView textView27,textView36;
    ArrayList<itemMail> ar = new ArrayList<>();
    String userID, key,A,B;
    FirebaseAuth firebaseAuth;
    FirebaseFirestore firebaseFirestore;
    int C=0,D=0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.mail);
        A="未領收";
        B="已領收";
        button7 = findViewById(R.id.button7);
        button8 = findViewById(R.id.button8);
        textView27 = findViewById(R.id.textView27);
        textView36 = findViewById(R.id.textView36);
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();
        userID = firebaseAuth.getCurrentUser().getUid();
        Calendar calendar = Calendar.getInstance();
        long dts = calendar.getTimeInMillis();
        long ets = dts+86400000;

        DocumentReference documentReference = firebaseFirestore.collection("users").document(userID);
        documentReference.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document != null) {
                        Log.d("TAG", "DocumentSnapshot data: " + document.getData());
                        key = document.getString("recID");
                        firebaseFirestore.collection("mail pack").whereEqualTo("ID", key.toString()).whereEqualTo("accept",A.toString()).addSnapshotListener((documentSnapshots, error) -> {
                            ar.clear();
                            for (DocumentSnapshot snapshot : documentSnapshots) {
                                Timestamp timestamp = (Timestamp) snapshot.getData().get("createdAt");
                                Date date = timestamp.toDate();
                                String date2 = date.toString();
                                Timestamp timestamp2 = (Timestamp) snapshot.getData().get("endtime");
                                Date date3 = timestamp2.toDate();
                                String date4 = date3.toString();
                                ar.add(new itemMail(R.drawable.mailpackbox, snapshot.getString("names"), "by " + snapshot.getString("createdBy"), date2, date4, snapshot.getString("accept")));
                                C++;
                                textView27.setText(Integer.toString(C));
                            }

                            adapterMail adapterMail = new adapterMail(getApplicationContext(), R.layout.list_row_mail, ar);
                            adapterMail.notifyDataSetChanged();
                            lv1.setAdapter(adapterMail);
                        });
                            lv1 = findViewById(R.id.lv2);
                            firebaseFirestore.collection("mail pack").whereEqualTo("ID", key.toString()).whereEqualTo("accept",A.toString()).whereLessThan("endtimesecond",ets).addSnapshotListener((documentSnapshots, error) -> {
                            for (DocumentSnapshot snapshot : documentSnapshots) {
                                Timestamp timestamp = (Timestamp) snapshot.getData().get("createdAt");
                                Date date = timestamp.toDate();
                                String date2 = date.toString();
                                Timestamp timestamp2 = (Timestamp) snapshot.getData().get("endtime");
                                Date date3 = timestamp2.toDate();
                                String date4 = date3.toString();
                                D++;
                                textView36.setText(Integer.toString(D));
                            }
                        });
                    }


                }
            }
        });

        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(mail.this, CommunityDaily.class));
            }
        });

        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DocumentReference documentReference = firebaseFirestore.collection("users").document(userID);
                documentReference.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                            if (document != null) {
                                Log.d("TAG", "DocumentSnapshot data: " + document.getData());
                                key = document.getString("recID");
                                firebaseFirestore.collection("mail pack").whereEqualTo("ID", key.toString()).whereEqualTo("accept",B.toString()).addSnapshotListener((documentSnapshots, error) -> {
                                    ar.clear();
                                    for (DocumentSnapshot snapshot : documentSnapshots) {
                                        Timestamp timestamp = (Timestamp) snapshot.getData().get("createdAt");
                                        Date date = timestamp.toDate();
                                        String date2 = date.toString();
                                        Timestamp timestamp2 = (Timestamp) snapshot.getData().get("modifytime");
                                        Date date3 = timestamp2.toDate();
                                        String date4 = date3.toString();
                                        ar.add(new itemMail(R.drawable.mailpackbox, snapshot.getString("names"), "by " + snapshot.getString("createdBy"), date2, date4, snapshot.getString("accept")));
                                    }
                                    adapterMail adapterMail = new adapterMail(getApplicationContext(), R.layout.list_row_mail, ar);
                                    adapterMail.notifyDataSetChanged();
                                    lv3.setAdapter(adapterMail);
                                });
                                lv3 = findViewById(R.id.lv2);

                                button7.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        startActivity(new Intent(mail.this, mail.class));
                                    }
                                });
                            }
                        }
                    }
                });
            }
        });

    }
}
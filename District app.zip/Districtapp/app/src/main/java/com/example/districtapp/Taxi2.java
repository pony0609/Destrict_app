package com.example.districtapp;

import android.content.Intent;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class Taxi2 extends AppCompatActivity {
    ArrayList<TaxiItem> mTaxiList,mTaxiList2;
    TaxiAdapter mAdapter;
    TaxiAdapter2 mAdapter2;
    Spinner spinner,spinner2,spinner3,spinner4;
    Button button1,button2,button7;
    String userID,hours,mins,key,cartype,carsize,modes,needtimes,types;
    int hour,min;
    TextView mode,needtime,type;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.taxi2);
        initList();
        initList2();
        FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
        FirebaseFirestore firebaseFirestore = FirebaseFirestore.getInstance();
        userID = firebaseAuth.getCurrentUser().getUid();
        button1 = findViewById(R.id.button1);
        button2 = findViewById(R.id.button2);
        button7 = findViewById(R.id.button7);
        mode = findViewById(R.id.mode);
        needtime = findViewById(R.id.needtime);
        type = findViewById(R.id.type);
        spinner = (Spinner) findViewById(R.id.spinner);
        spinner2 = (Spinner) findViewById(R.id.spinner2);
        spinner3 = (Spinner) findViewById(R.id.spinner3);
        spinner4 = (Spinner) findViewById(R.id.spinner4);
        mAdapter = new TaxiAdapter(this,mTaxiList);
        mAdapter2 = new TaxiAdapter2(this,mTaxiList2);
        spinner.setAdapter(mAdapter);
        spinner2.setAdapter(mAdapter2);
        spinner.getBackground().setColorFilter(getResources().getColor(R.color.back), PorterDuff.Mode.SRC_ATOP);
        spinner2.getBackground().setColorFilter(getResources().getColor(R.color.back), PorterDuff.Mode.SRC_ATOP);
        Calendar calendar2 = Calendar.getInstance();
        hour = calendar2.get(Calendar.HOUR_OF_DAY);
        min = calendar2.get(Calendar.MINUTE);
        hours = String.valueOf(hour);
        mins = String.valueOf(min);
        DocumentReference documentReference = firebaseFirestore.collection("users").document(userID);
        documentReference.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                DocumentSnapshot document = task.getResult();
                key = document.getString("recID");
                DocumentReference documentReference2 = firebaseFirestore.collection("taxi").document(key.toString());
                documentReference2.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        DocumentSnapshot document = task.getResult();
                        modes = document.getString("mode");
                        mode.setText(modes);
                        needtimes = document.getString("reservationTime");
                        needtime.setText(needtimes);
                        types = document.getString("type");
                        type.setText(types);
                    }
                });
            }
        });
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                TaxiItem clickedItem = (TaxiItem) parent.getItemAtPosition(position);
                cartype= clickedItem.getmTaxiName();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                TaxiItem clickedItem = (TaxiItem) parent.getItemAtPosition(position);
                carsize = clickedItem.getmTaxiName();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Taxi2.this, CommunityDaily.class));
            }
        });

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Map<String, Object> taxi = new HashMap<>();
                taxi.put("reservation", "非預約");
                taxi.put("mode", "未叫車");
                taxi.put("type", carsize+cartype);
                taxi.put("time", hours+":"+mins);
                taxi.put("recID", key);
                taxi.put("reservationTime", hours+":"+mins);
                firebaseFirestore.collection("taxi").document(key.toString()).set(taxi).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(Taxi2.this, "已通知叫車", Toast.LENGTH_LONG).show();
                            startActivity(new Intent(Taxi2.this, Taxi2.class));
                        }
                    }
                });
            }
        });

    }

    private void initList(){
        mTaxiList = new ArrayList<>();
        mTaxiList.add(new TaxiItem("計程車", R.drawable.taxiicon));
        mTaxiList.add(new TaxiItem("舒適型", R.drawable.caricon));
    }

    private void initList2(){
        mTaxiList2 = new ArrayList<>();
        mTaxiList2.add(new TaxiItem("小型", R.drawable.taxiperson));
        mTaxiList2.add(new TaxiItem("大型", R.drawable.taxipeople));
    }


}

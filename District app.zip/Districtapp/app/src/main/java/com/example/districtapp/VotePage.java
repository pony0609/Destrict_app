package com.example.districtapp;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class VotePage extends AppCompatActivity implements Serializable {
Button button_agree,button_disagree,button7;
TextView vote_title,vote_create,vote_start,vote_end,vote_content;
    FirebaseAuth firebaseAuth;
    FirebaseFirestore firebaseFirestore;
    String voteId,userID;
    ListView lv2;
    int agree,agree2;
    int disagree,disagree2;

    ArrayList<item2> ar = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.votepage);
        button7 = findViewById(R.id.button7);
        button_agree = findViewById(R.id.button);
        button_disagree = findViewById(R.id.button22);
        vote_title = findViewById(R.id.textView7);
        vote_create = findViewById(R.id.textView8);
        vote_start = findViewById(R.id.textView9);
        vote_end = findViewById(R.id.textView10);
        vote_content = findViewById(R.id.textView11);
        lv2 = findViewById(R.id.lv2);
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();
        userID = firebaseAuth.getCurrentUser().getUid();

        if (savedInstanceState == null) {
            Bundle extras = getIntent().getExtras();
            if (extras == null) {
                voteId = null;
            } else {
                voteId = extras.getString("voteId");
            }
        } else {
            voteId = (String) savedInstanceState.getSerializable("voteId");
        }
        DocumentReference docRef2 = firebaseFirestore.collection("users").document(userID).collection("vote").document(voteId);

            docRef2.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                    if (task.isSuccessful()) {
                        DocumentSnapshot document = task.getResult();
                        if (document.exists()) {
                            Log.d("TAG", "DocumentSnapshot data: " + document.getData());
                            AlertDialog.Builder builder1 = new AlertDialog.Builder(VotePage.this);
                            builder1.setMessage("您已投過該投票");
                            builder1.setCancelable(true);

                            builder1.setPositiveButton(
                                    "確定返回",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            dialog.cancel();
                                            startActivity(new Intent(VotePage.this, VoteMain.class));

                                        }
                                    });


                            AlertDialog alert11 = builder1.create();
                            alert11.show();

                        }
                    } else {
                        Log.d("TAG", "No such document");
                    }
                }

            });


        DocumentReference docRef = firebaseFirestore.collection("vote").document(voteId);
        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        Log.d("TAG", "DocumentSnapshot data: " + document.getData());
                        vote_title.setText(document.getString("vote_title"));
                        vote_create.setText(document.getString("createdBy"));
                        vote_start.setText(document.getString("start_time"));
                        vote_end.setText(document.getString("end_time"));
                        vote_content.setText(document.getString("vote_content"));
                        ar.add(new item2(document.getString("vote_title"), document.getString("vote_description")));
                        agree = document.getLong("agree").intValue();
                        disagree = document.getLong("disagree").intValue();
                    } else {
                        Log.d("TAG", "No such document");
                    }
                } else {
                    Log.d("TAG", "get failed with ", task.getException());
                }
                adapter3 adapter3 = new adapter3(getApplicationContext(), R.layout.list_row_convent, ar);
                adapter3.notifyDataSetChanged();
                lv2.setAdapter(adapter3);
            }
        });


        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(VotePage.this, VoteMain.class));
            }
        });
        button_agree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                docRef2.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                            if (document.exists()) {
                                Log.d("TAG", "DocumentSnapshot data: " + document.getData());
                                AlertDialog.Builder builder1 = new AlertDialog.Builder(VotePage.this);
                                builder1.setMessage("您已投過該投票");
                                builder1.setCancelable(true);

                                builder1.setPositiveButton(
                                        "確定返回",
                                        new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                dialog.cancel();
                                                startActivity(new Intent(VotePage.this, VoteMain.class));

                                            }
                                        });


                                AlertDialog alert11 = builder1.create();
                                alert11.show();

                            }
                        } else {
                            Log.d("TAG", "No such document");
                        }
                    }

                });

                AlertDialog.Builder builder1 = new AlertDialog.Builder(VotePage.this);
                builder1.setMessage("確定投下同意票嗎?一經投票不可更改.");
                builder1.setCancelable(true);

                builder1.setPositiveButton(
                        "Yes",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();

                                Map<String, Object> vote = new HashMap<>();
                                agree++;
                                vote.put("agree", agree);

                                firebaseFirestore.collection("vote").document(voteId).update(vote).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            Toast.makeText(VotePage.this, "voted succesfully", Toast.LENGTH_LONG).show();


                                        }
                                    }
                                });
                                firebaseFirestore.collection("users").document(userID).collection("vote").document(voteId).set(vote).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            //Toast.makeText(VotePage.this, "voted succesfully", Toast.LENGTH_LONG).show();


                                        }
                                    }
                                });
                            }
                        });

                builder1.setNegativeButton(
                        "No",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });

                AlertDialog alert11 = builder1.create();
                alert11.show();

            }

        });
        button_disagree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                docRef2.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                            if (document.exists()) {
                                Log.d("TAG", "DocumentSnapshot data: " + document.getData());
                                AlertDialog.Builder builder1 = new AlertDialog.Builder(VotePage.this);
                                builder1.setMessage("您已投過該投票");
                                builder1.setCancelable(true);

                                builder1.setPositiveButton(
                                        "確定返回",
                                        new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                dialog.cancel();
                                                startActivity(new Intent(VotePage.this, VoteMain.class));

                                            }
                                        });


                                AlertDialog alert11 = builder1.create();
                                alert11.show();

                            }
                        } else {
                            Log.d("TAG", "No such document");
                        }
                    }

                });

                AlertDialog.Builder builder1 = new AlertDialog.Builder(VotePage.this);
                builder1.setMessage("確定投下否決票嗎?一經投票不可更改.");
                builder1.setCancelable(true);

                builder1.setPositiveButton(
                        "Yes",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();

                                Map<String, Object> vote = new HashMap<>();
                                disagree++;
                                vote.put("disagree", disagree);

                                firebaseFirestore.collection("vote").document(voteId).update(vote).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            Toast.makeText(VotePage.this, "voted succesfully", Toast.LENGTH_LONG).show();


                                        }
                                    }
                                });
                                firebaseFirestore.collection("users").document(userID).collection("vote").document(voteId).set(vote).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            //Toast.makeText(VotePage.this, "voted succesfully", Toast.LENGTH_LONG).show();


                                        }
                                    }
                                });
                            }
                        });

                builder1.setNegativeButton(
                        "No",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });

                AlertDialog alert11 = builder1.create();
                alert11.show();

            }

        });




    }
}
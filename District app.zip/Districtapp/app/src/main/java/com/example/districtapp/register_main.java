package com.example.districtapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class register_main extends AppCompatActivity {

    EditText username,password,email;
    TextView registernow;
    private FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);
        registernow = findViewById(R.id.registernow);
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        email = findViewById(R.id.email);

firebaseAuth = FirebaseAuth.getInstance();
registernow.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        String user_Email = email.getText().toString().trim();
        String user_Name = username.getText().toString().trim();
        String Password = password.getText().toString().trim();
        firebaseAuth.createUserWithEmailAndPassword(user_Email,Password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    Toast.makeText(register_main.this,"Registration succesful",Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(register_main.this,MainActivity.class));
                }else {
                    Toast.makeText(register_main.this,"Registration failed",Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
});
    }
}

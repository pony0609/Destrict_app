package com.example.districtapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class register_main extends AppCompatActivity {


    EditText username,password,email;
    TextView registernow;
    String userID;
    private FirebaseAuth firebaseAuth;
    FirebaseFirestore firebaseFirestore;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);
        registernow = findViewById(R.id.registernow);
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        email = findViewById(R.id.title);

firebaseAuth = FirebaseAuth.getInstance();
firebaseFirestore = FirebaseFirestore.getInstance();
registernow.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        final String user_Email = email.getText().toString().trim();
        final String user_Name = username.getText().toString().trim();
        final String Password = password.getText().toString().trim();
        if(user_Email.isEmpty()|user_Name.isEmpty()|Password.isEmpty()){
            Toast.makeText(register_main.this, "please enter", Toast.LENGTH_SHORT).show();
        }else {
            firebaseAuth.createUserWithEmailAndPassword(user_Email,Password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) {
                        Toast.makeText(register_main.this, "Registration succesful", Toast.LENGTH_SHORT).show();
                        userID = firebaseAuth.getCurrentUser().getUid();
                        DocumentReference documentReference = firebaseFirestore.collection("users").document(userID);
                        Map<String, Object> user = new HashMap<>();
                        user.put("user_name", user_Name);
                        user.put("email", user_Email);
                        user.put("password", Password);
                        documentReference.set(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Log.d("TAG", " profile is create for" + userID);
                            }
                        });
                        documentReference.set(user).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.d("TAG", " Onfailure" + e.toString());
                            }
                        });
                        startActivity(new Intent(register_main.this, MainActivity.class));
                    } else {
                        Toast.makeText(register_main.this, "Registration failed", Toast.LENGTH_SHORT).show();
                    }


                }
            });
        }


    }
});
    }
}

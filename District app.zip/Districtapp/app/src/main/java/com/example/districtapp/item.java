package com.example.districtapp;

import java.io.Serializable;

public class item implements Serializable {
    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDes() {
        return Des;
    }

    public void setDes(String des) {
        Des = des;
    }

    int image;
    String name;
    String Des;
    public item(int image, String name, String des) {
        this.image = image;
        this.name = name;
        Des = des;
    }


}

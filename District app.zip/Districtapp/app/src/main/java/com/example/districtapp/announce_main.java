package com.example.districtapp;

import android.content.ClipData;
import android.content.DialogInterface;
import android.content.Intent;
import android.nfc.Tag;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Date;

public class announce_main extends AppCompatActivity {
    Button button7;
    ListView lv1;
    ArrayList<itemAnnounce> ar = new ArrayList<>();
    String userID, announcement,idlv,url;
    FirebaseAuth firebaseAuth;
    FirebaseFirestore firebaseFirestore;
    item item;
    int x;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.announce_listview);
        button7 = findViewById(R.id.button7);
      //  item = (item) getIntent().getSerializableExtra("item");


        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();
        userID = firebaseAuth.getCurrentUser().getUid();
        firebaseFirestore.collection("announcement").orderBy("createdAt", Query.Direction.DESCENDING).addSnapshotListener((documentSnapshots, error) -> {
            ar.clear();

                for (DocumentSnapshot snapshot : documentSnapshots){
                    idlv = snapshot.getId();
                Timestamp timestamp = (Timestamp) snapshot.getData().get("createdAt");
                Date date = timestamp.toDate();
                String date2 = date.toString();
                String artLv = snapshot.getString("artLevel");
                Log.d("TAG", " artLevel is" + artLv);
                url = snapshot.getString("photoU  rl");


                if(artLv.equals("緊急公告")){
                    ar.add(new itemAnnounce(R.drawable.alarm, snapshot.getString("title"),"by "+snapshot.getString("createdBy")+ " 類型:"+snapshot.getString("artLevel"),date2,snapshot.getString("content"),idlv,url));
                }else if(artLv.equals("議題公告")){

                    ar.add(new itemAnnounce(R.drawable.newspaper, snapshot.getString("title"),"by "+snapshot.getString("createdBy")+ " 類型:"+snapshot.getString("artLevel"),date2,snapshot.getString("content"),idlv,url));
                }else{

                    ar.add(new itemAnnounce(R.drawable.teatime, snapshot.getString("title"),"by "+snapshot.getString("createdBy")+ " 類型:"+snapshot.getString("artLevel"),date2,snapshot.getString("content"),idlv,url));
                }

            }
            adapterAnnounce adapterAnnounce = new adapterAnnounce(getApplicationContext(), R.layout.list_row_announce, ar);
            adapterAnnounce.notifyDataSetChanged();
            lv1.setAdapter(adapterAnnounce);

            lv1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Object selectedObj =adapterAnnounce.getItem(position).getId();// this will get you selected obj of itemAnnounce
                    String obj = (String)selectedObj.toString();

                    Intent i = new Intent(announce_main.this, announce_Page.class);
                    i.putExtra("annId",obj);
                    startActivity(i);
                }
            });
        });
        lv1 = findViewById(R.id.lv2);

button7.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        startActivity(new Intent(announce_main.this, HomePageActivity.class));
    }
});





    }




}

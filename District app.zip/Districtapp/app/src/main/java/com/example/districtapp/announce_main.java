package com.example.districtapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class announce_main extends AppCompatActivity {
    Button create_button;
    ListView lv1;
    ArrayList<item> ar = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.announce_listview);
        create_button = findViewById(R.id.create_button);


        lv1 = findViewById(R.id.lv);
        final ArrayList<item> ar = (ArrayList<item>) getIntent().getExtras().getSerializable("record");

        final adapter2 adapter2 = new adapter2(announce_main.this, R.layout.list_row, ar);
        lv1.setAdapter(adapter2);

        create_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(announce_main.this, create_announce_main.class);
                startActivity(intent);
            }
        });


    }

}

package com.example.districtapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class announce_main extends AppCompatActivity {
    Button create_button, delete;
    ListView lv1;
    ArrayList<item> ar = new ArrayList<>();
    String userID,announcement;
    FirebaseAuth firebaseAuth;
    FirebaseFirestore firebaseFirestore;
    Integer pos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.announce_listview);
        delete = findViewById(R.id.delete);
        create_button = findViewById(R.id.create_button);
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();
        userID = firebaseAuth.getCurrentUser().getUid();
        firebaseFirestore.collection("announcement").addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot documentSnapshots, @Nullable FirebaseFirestoreException error) {
                ar.clear();
                for (DocumentSnapshot snapshot : documentSnapshots) {
                    ar.add(new item(R.drawable.ann3, snapshot.getString("title"), snapshot.getString("content")));
                }
                adapter2 adapter2 = new adapter2(getApplicationContext(), R.layout.list_row, ar);
                adapter2.notifyDataSetChanged();
                lv1.setAdapter(adapter2);
            }
        });

        lv1 = findViewById(R.id.lv);
        // final ArrayList<item> ar = (ArrayList<item>) getIntent().getExtras().getSerializable("record");
        // final adapter2 adapter2 = new adapter2(announce_main.this, R.layout.list_row, ar);
        //lv1.setAdapter(adapter2);
        //old one

        create_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(announce_main.this, create_announce_main.class);
                startActivity(intent);
            }
        });


        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(announce_main.this);
                builder.setTitle("確定刪除公告嗎");
                builder.setMessage("資料將永久從雲端資料庫中刪除");
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        deleteProduct();
                    }
                });
                builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();

            }
        });
        lv1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                AlertDialog.Builder builder = new AlertDialog.Builder(announce_main.this);
                builder.setTitle("確定刪除公告嗎");
                builder.setMessage("資料將永久從雲端資料庫中刪除");
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        deleteProduct();
                    }
                });
                builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });



    }

    private void deleteProduct() {
   firebaseFirestore.collection("announcement").document().delete().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    Toast.makeText(announce_main.this, "delete succesfully", Toast.LENGTH_LONG).show();
                    finish();
                    Intent intent = new Intent(announce_main.this, HomePageActivity.class);
                    startActivity(intent);
                }
            }


        });
    }


}

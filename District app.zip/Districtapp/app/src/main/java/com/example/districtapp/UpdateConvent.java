package com.example.districtapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class UpdateConvent extends AppCompatActivity {
    String userID;
    private FirebaseAuth firebaseAuth;
    FirebaseFirestore firebaseFirestore;
    EditText art1, art2;
    Button back,sendover;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.update_convent);
        art1 = findViewById(R.id.art1);
        art2 = findViewById(R.id.art2);
        back = findViewById(R.id.back);
        sendover = findViewById(R.id.sendover);
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();

        back.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              Intent intent = new Intent(UpdateConvent.this, ConventMain.class);
              startActivity(intent);
          }
      });
      sendover.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              String title = art1.getText().toString();
              String content = art2.getText().toString();


              Intent intent = new Intent(UpdateConvent.this, ConventMain.class);
              userID = firebaseAuth.getCurrentUser().getUid();
              Map<String, Object> convent = new HashMap<>();
              convent.put("title", title);
              convent.put("content", content);
              firebaseFirestore.collection("convent").document().set(convent).addOnCompleteListener(new OnCompleteListener<Void>() {
                  @Override
                  public void onComplete(@NonNull Task<Void> task) {
                      if (task.isSuccessful()) {
                          Toast.makeText(UpdateConvent.this, "added succesfully", Toast.LENGTH_LONG).show();


                      }
                  }
              });

              startActivity(intent);
          }
      });
    }


}

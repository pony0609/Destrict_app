package com.example.districtapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;
import java.util.Date;

public class FeeRDPage extends AppCompatActivity {
    ListView lv1;
    ArrayList<itemAnnounce> ar = new ArrayList<>();
    Button button7;
    FirebaseAuth firebaseAuth;
    FirebaseFirestore firebaseFirestore;
    String userID,url,idlv;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.feerdpage);
        button7 = findViewById(R.id.button7);

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();
        userID = firebaseAuth.getCurrentUser().getUid();

        firebaseFirestore.collection("users").document(userID).collection("feeManage").addSnapshotListener((documentSnapshots, error) -> {
            ar.clear();

            for (DocumentSnapshot snapshot : documentSnapshots){
                idlv = snapshot.getId();

                if (snapshot.getDate("付款日期") != null) {
                    Timestamp timestamp = (Timestamp) snapshot.getData().get("付款日期");
                    Date date = timestamp.toDate();
                    String date2 = date.toString();
                    ar.add(new itemAnnounce(R.drawable.teatime, snapshot.getString("繳費期別"),"付款方式:"+snapshot.getString("付款方式"),"繳費日期:"+date2,snapshot.getString("繳費狀態"),idlv,url));
                }



            }
            adapterAnnounce adapterAnnounce = new adapterAnnounce(getApplicationContext(), R.layout.list_row_announce, ar);
            adapterAnnounce.notifyDataSetChanged();
            lv1.setAdapter(adapterAnnounce);

        });
        lv1 = findViewById(R.id.lv2);



        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FeeRDPage.this, FeePage1.class));
            }
        });

    }
}

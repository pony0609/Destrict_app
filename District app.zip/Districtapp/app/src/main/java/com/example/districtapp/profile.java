package com.example.districtapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class profile extends AppCompatActivity{
    FirebaseAuth firebaseAuth;
    FirebaseFirestore firebaseFirestore;
    StorageReference storageReference;
    ProgressDialog progressDialog;
    String userID,ImageUrl,fileName,propic;
    Button button7;
    TextView TextView6,send;
    ImageView imageView3;
    int ss;
    Uri imageUri;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile);
        final TextView acname = findViewById(R.id.acname);
        final TextView ac = findViewById(R.id.ac);
        final TextView pw = findViewById(R.id.pw);
        final TextView date = findViewById(R.id.textView76);
        final TextView address = findViewById(R.id.textView73);
        final TextView phone = findViewById(R.id.textView74);
        final TextView square = findViewById(R.id.textView75);
        button7 = findViewById(R.id.button7);
        TextView6 = findViewById(R.id.textView6);
        send = findViewById(R.id.textView87);
        imageView3 = findViewById(R.id.imageView3);
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();
        userID = firebaseAuth.getCurrentUser().getUid();

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss", Locale.TAIWAN);
        Date now = new Date();
        fileName = formatter.format(now);

        DocumentReference documentReference = firebaseFirestore.collection("users").document(userID);
        documentReference.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                Timestamp timestamp = (Timestamp) documentSnapshot.getData().get("createdAt");
                Date date3 = timestamp.toDate();
                String date2 = date3.toString();
                date.setText(date2);
                address.setText(documentSnapshot.getString("address"));
                phone.setText(documentSnapshot.getString("phone"));
                ss = documentSnapshot.getLong("square").intValue();
                String sss = String.valueOf(ss);
                square.setText(sss);
                acname.setText(documentSnapshot.getString("user_name"));
                ac.setText(documentSnapshot.getString("email"));
                pw.setText(documentSnapshot.getString("recID"));
                propic = documentSnapshot.getString("照片");
                if(propic.isEmpty()){

                }else{
                    Glide.with(getApplicationContext())
                            .load(propic)
                            .into(imageView3);
                }
            }
        });
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(profile.this, HomePageActivity.class));
            }
        });
        TextView6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                firebaseAuth.getInstance().signOut();
                startActivity(new Intent(profile.this, MainActivity.class));
            }
        });
        imageView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               selectImage();
            }
        });
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(imageUri != null && !imageUri.equals(Uri.EMPTY)){
                    uploadImage();
                }else{
                    selectImage();
                }

            }
        });


    }
    private void selectImage() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent,100);
    }
    private void uploadImage() {
        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Uploading File....");
        progressDialog.show();



        storageReference = FirebaseStorage.getInstance().getReference("imagesUsersProfile/"+fileName);



        storageReference.putFile(imageUri)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        storageReference.getDownloadUrl().addOnCompleteListener(new OnCompleteListener<Uri>() {
                            @Override
                            public void onComplete(@NonNull Task<Uri> task) {
                                ImageUrl=task.getResult().toString();
                                Log.i("URL",ImageUrl);

                                Map<String, Object> pic = new HashMap<>();
                                pic.put("照片", ImageUrl);
                                firebaseFirestore.collection("users").document(userID).update(pic).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            Toast.makeText(profile.this, "added url succesfully", Toast.LENGTH_LONG).show();


                                        }
                                    }
                                });
                            }
                        });
                        imageView3.setImageURI(null);
                        Toast.makeText(profile.this,"Successfully Uploaded",Toast.LENGTH_SHORT).show();
                        if (progressDialog.isShowing())
                            progressDialog.dismiss();

                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {


                if (progressDialog.isShowing())
                    progressDialog.dismiss();
                Toast.makeText(profile.this,"Failed to Upload Picture",Toast.LENGTH_SHORT).show();


            }
        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 100 && data != null && data.getData() != null){

            imageUri = data.getData();
            imageView3.setImageURI(imageUri);



        }
    }
}
